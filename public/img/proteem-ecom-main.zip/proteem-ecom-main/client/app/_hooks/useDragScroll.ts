import { useRef, useEffect, useState } from "react";

export function useDragScroll() {
  const ref = useRef<HTMLDivElement>(null);
  const [isAtStart, setIsAtStart] = useState(true);
  const [isAtEnd, setIsAtEnd] = useState(false);

  const updateEdges = () => {
    const el = ref.current;
    if (!el) return;
    setIsAtStart(el.scrollLeft <= 0);
    setIsAtEnd(el.scrollLeft + el.clientWidth >= el.scrollWidth - 5);
  };

  useEffect(() => {
    const slider = ref.current;
    if (!slider) return;

    let isDown = false;
    let startX = 0;
    let scrollLeft = 0;

    const mouseDown = (e: MouseEvent) => {
      isDown = true;
      startX = e.clientX;
      scrollLeft = slider.scrollLeft;
      slider.classList.add("dragging");
    };

    const mouseMove = (e: MouseEvent) => {
      if (!isDown) return;
      const dx = e.clientX - startX;
      slider.scrollLeft = scrollLeft - dx;
      updateEdges();
    };

    const mouseUp = () => {
      isDown = false;
      slider.classList.remove("dragging");
    };

    slider.addEventListener("mousedown", mouseDown);
    slider.addEventListener("mousemove", mouseMove);
    window.addEventListener("mouseup", mouseUp);
    slider.addEventListener("scroll", updateEdges);

    updateEdges(); // initial state

    return () => {
      slider.removeEventListener("mousedown", mouseDown);
      slider.removeEventListener("mousemove", mouseMove);
      window.removeEventListener("mouseup", mouseUp);
      slider.removeEventListener("scroll", updateEdges);
    };
  }, []);

  return { ref, isAtStart, isAtEnd };
}
