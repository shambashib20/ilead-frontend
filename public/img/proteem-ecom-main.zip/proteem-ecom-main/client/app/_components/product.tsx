// components/Product.tsx
import Image from "next/image";
import React from "react";
import { useDragScroll } from "../_hooks/useDragScroll";

type ProductCardProps = {
  title: string;
  price: string | number;
  image: string;
};

export default function Product({ title, price, image }: ProductCardProps) {
  return (
    <article
      className="
          rounded-2xl 
        bg-gradient-to-b 
        from-[#1E3A39] 
        to-[#181818] 
        shadow-[0_8px_32px_-8px_rgba(0,25,25,0.12)] 
        overflow-hidden
        flex flex-col
        w-[300px]
        flex-shrink-0
      "
    >
      <div className="w-full relative">
        <Image
          src={image}
          height={300}
          width={300}
          alt={title}
          className="w-full  object-cover"
        />
      </div>

      <div className="md:px-5 md:pb-4 px-1.5 pb-1.5">
        <h3 className="text-[18px] font-bold text-white mb-[6px] min-h-[55px] max-w-[290px]">
          {title}
        </h3>

        <div className="flex justify-between items-start">
          <h4 className="text-white text-[20px] font-bold">${price}</h4>
        </div>

        <ul className="flex md:flex-row flex-col items-center mt-3 gap-2">
          <li>
            <button
              type="button"
              className="
                bg-[#E6F2F2] 
                text-[#006662] 
                text-[14px] 
                font-semibold 
                px-1.5 
                py-[7px] 
                rounded-sm 
                flex items-center justify-center gap-1.5 
                w-full 
                cursor-pointer
              "
            >
              <Image
                src="/assets/cart_icon2.png"
                alt="add to cart icon"
                width={12}
                height={12}
              />
            </button>
          </li>

          <li className="md:flex-1 flex-none w-full">
            <button
              type="button"
              className="
                text-[#E6F2F2] 
                text-[14px] 
                font-bold 
                bg-[#006662] 
                px-1.5 
                py-[4px] 
                rounded-sm 
                flex items-center justify-center gap-1.5 
                w-full 
                cursor-pointer
              "
            >
              <Image
                src="/assets/fast_icon.png"
                alt="buy now icon"
                width={12}
                height={12}
              />
              Buy Now
            </button>
          </li>
        </ul>
      </div>
    </article>
  );
}
