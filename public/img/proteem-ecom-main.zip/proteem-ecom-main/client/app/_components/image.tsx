// components/ResponsiveColorImage.tsx
import React from "react";
import { getImageProps } from "next/image";

type Props = {
  desktopSrc: string;
  mobileSrc: string;
  alt?: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  sizes?: string;
  mobileMaxWidth?: number;
};

export default function ResponsiveImage({
  desktopSrc,
  mobileSrc,
  alt = "",
  width = 1200,
  height = 600,
  className,
  priority = false,
  sizes = "100vw",
  mobileMaxWidth = 640,
}: Props) {
  const common = { alt, width, height, priority, sizes };

  const {
    props: { srcSet: mobileSrcSet },
  } = getImageProps({
    ...common,
    src: mobileSrc,
  });

  const {
    props: { srcSet: desktopSrcSet, src: fallbackSrc, ...rest },
  } = getImageProps({
    ...common,
    src: desktopSrc,
  });

  return (
    <picture className={className}>
      <source
        media={`(max-width: ${mobileMaxWidth}px)`}
        srcSet={mobileSrcSet}
      />
      <source
        media={`(min-width: ${mobileMaxWidth + 1}px)`}
        srcSet={desktopSrcSet}
      />
      <img
        src={fallbackSrc}
        alt={alt}
        {...(rest as React.ImgHTMLAttributes<HTMLImageElement>)}
      />
    </picture>
  );
}
