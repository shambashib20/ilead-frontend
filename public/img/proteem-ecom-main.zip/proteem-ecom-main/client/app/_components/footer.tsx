import Image from "next/image";
import React from "react";

function Footer() {
  return (
    <footer className="text-white md:py-[60px] py-[20px] bg-[#222222]">
      <div className="max-w-[1170px] w-full mx-auto px-4">
        <div className="grid md:grid-cols-3 md:gap-[60px] gap-[20px] grid-cols-1">
          <div className="col">
            <h3 className="text-[16px] font-medium border-b border-[#757575] uppercase pb-[8px] mb-[16px]">
              About Proteem™ LLC.
            </h3>

            <div className="grid grid-cols-2 gap-[14px_60px] ">
              <div className="col ">
                <h4 className="text-[12px] font-medium flex flex-col gap-[4px] uppercase text-[#CCCCCC]">
                  Address:{" "}
                  <span className="text-[14px] normal-case font-normal text-white">
                    33 Bernhard Road Suite B North Haven, Connecticut 0647
                  </span>
                </h4>
              </div>
              <div className="col ">
                <h4 className="text-[12px] font-medium flex flex-col gap-[4px] uppercase text-[#CCCCCC]">
                  Fax:
                  <span className="text-[14px] normal-case font-normal text-white">
                    203-787-2231
                  </span>
                </h4>
              </div>

              <div className="col">
                <h4 className="text-[12px] font-medium flex flex-col gap-[4px] uppercase text-[#CCCCCC] uppercase text-[#CCCCCC]">
                  Toll Free:{" "}
                  <span className="text-[14px] normal-case font-normal text-white">
                    877-787-2221
                  </span>
                </h4>
              </div>
              <div className="col">
                <h4 className="text-[12px] font-medium flex flex-col gap-[4px] uppercase text-[#CCCCCC]">
                  Phone:{" "}
                  <span className="text-[14px] normal-case font-normal text-white">
                    203-787-2221
                  </span>
                </h4>
              </div>

              <div className="col">
                <h4 className="text-[12px] font-medium flex flex-col gap-[4px] uppercase text-[#CCCCCC]">
                  Email:{" "}
                  <span className="text-[14px] normal-case font-normal text-white">
                    mhogan@promednutrition.com
                  </span>
                  <span className="text-[14px] normal-case font-normal text-white">
                    mark@proteem.com
                  </span>
                </h4>
              </div>
            </div>
          </div>

          <div className="col">
            <h3 className="text-[16px] font-medium border-b border-[#757575] uppercase pb-[8px] mb-[16px]">
              Information
            </h3>

            <div className="grid grid-cols-2">
              <div className="col space-y-[14px]">
                <h4 className="text-[14px] font-normal">Shop</h4>
                <h4 className="text-[14px] font-normal">Trainer’s Corner</h4>
                <h4 className="text-[14px] font-normal">Recipes</h4>
                <h4 className="text-[14px] font-normal">Why Proteem™?</h4>
                <h4 className="text-[14px] font-normal">About Us</h4>
              </div>
              <div className="col space-y-[14px]">
                <h4 className="text-[14px] font-normal">Shop</h4>
                <h4 className="text-[14px] font-normal">Trainer’s Corner</h4>
                <h4 className="text-[14px] font-normal">Recipes</h4>
                <h4 className="text-[14px] font-normal">Why Proteem™?</h4>
                <h4 className="text-[14px] font-normal">About Us</h4>
              </div>
            </div>
          </div>

          <div className="col space-y-[14px]">
            <h3 className="text-[16px] font-medium border-b border-[#757575] pb-[8px] mb-[16px]">
              Trainer’s Corner
            </h3>

            <div className="grid grid-cols-1">
              <div className="col space-y-[14px]">
                <h4 className="text-[14px] font-normal flex flex-col gap-1">
                  Creatine in Health and Disease{" "}
                  <span className="text-[12px] font-medium uppercase">
                    by Mark Hogan
                  </span>
                </h4>
                <h4 className="text-[14px] font-normal flex flex-col gap-1">
                  Creatine in Health and Disease{" "}
                  <span className="text-[12px] font-medium uppercase">
                    by Mark Hogan
                  </span>
                </h4>
                <h4 className="text-[14px] font-normal flex flex-col gap-1">
                  Creatine in Health and Disease{" "}
                  <span className="text-[12px] font-medium uppercase">
                    by Mark Hogan
                  </span>
                </h4>
                <h4 className="text-[14px] font-normal flex flex-col gap-1">
                  Creatine in Health and Disease{" "}
                  <span className="text-[12px] font-medium uppercase">
                    by Mark Hogan
                  </span>
                </h4>
                <h4 className="text-[14px] font-normal flex flex-col gap-1">
                  Creatine in Health and Disease{" "}
                  <span className="text-[12px] font-medium uppercase">
                    by Mark Hogan
                  </span>
                </h4>
              </div>
            </div>
          </div>
        </div>

        <div
          className="bottom md:mt-[40px]  mt-[20px]  border-t border-[#757575] pt-[25px] 
  grid md:grid-cols-3  grid-cols-1 gap-2 items-center text-center"
        >
          <h5 className="text-[12px] font-medium">Secure Online Shopping</h5>

          <ul className="flex justify-center gap-[14px] items-center">
            <li>
              <Image
                src="/assets/paypal.png"
                alt="paypal"
                width={60}
                height={40}
              />
            </li>
            <li>
              <Image
                src="/assets/visa.png"
                alt="paypal"
                width={60}
                height={40}
              />
            </li>
            <li>
              <Image
                src="/assets/discover.png"
                alt="paypal"
                width={60}
                height={40}
              />
            </li>
            <li>
              <Image
                src="/assets/master.png"
                alt="paypal"
                width={60}
                height={40}
              />
            </li>
          </ul>

          <h5 className="text-[12px] font-medium">
            © 2025 Proteem.com, All Rights Reserved.
          </h5>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
