"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useDragScroll } from "../_hooks/useDragScroll";

export function ProductContainer({
  children,
  className = "",
}: {
  children: React.ReactNode[];
  className?: string;
}) {
  const { ref, isAtStart, isAtEnd } = useDragScroll();

  // Split by index parity (THIS FIXES EVERYTHING)
  const row1 = children.filter((_, i) => i % 2 === 0);
  const row2 = children.filter((_, i) => i % 2 === 1);

  const scrollByAmount = (amount: number) => {
    if (!ref.current) return;
    ref.current.scrollBy({ left: amount, behavior: "smooth" });
  };

  return (
    <div className="relative w-full">
      {/* LEFT ARROW */}
      <button
        disabled={isAtStart}
        onClick={() => scrollByAmount(-300)}
        className={`
          absolute left-0 top-1/2 -translate-y-1/2 z-10
          p-2 rounded-full bg-black/40 backdrop-blur
          hover:bg-black/60 transition
          ${isAtStart ? "opacity-30 cursor-not-allowed" : "cursor-pointer"}
        `}
      >
        <ChevronLeft className="text-white" />
      </button>

      {/* RIGHT ARROW */}
      <button
        disabled={isAtEnd}
        onClick={() => scrollByAmount(300)}
        className={`
          absolute right-0 top-1/2 -translate-y-1/2 z-10
          p-2 rounded-full bg-black/40 backdrop-blur
          hover:bg-black/60 transition
          ${isAtEnd ? "opacity-30 cursor-not-allowed" : "cursor-pointer"}
        `}
      >
        <ChevronRight className="text-white" />
      </button>

      {/* SCROLLER */}
      <div
        ref={ref}
        className={
          "drag-container flex flex-col gap-4 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory  " +
          className
        }
      >
        {/* ROW 1 */}
        <div className="flex gap-4 flex-shrink-0">
          {row1.map((child, i) => (
            <div key={i} className="snap-start flex-shrink-0">
              {child}
            </div>
          ))}
        </div>

        {/* ROW 2 */}
        <div className="flex gap-4 flex-shrink-0">
          {row2.map((child, i) => (
            <div key={i} className="snap-start flex-shrink-0">
              {child}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
