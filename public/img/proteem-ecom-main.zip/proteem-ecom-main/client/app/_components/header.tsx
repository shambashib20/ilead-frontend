// components/Header.tsx
"use client"; // if using app/ directory and React client component
import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart, LogIn, LogOut } from "lucide-react";

const NAV_ITEMS = [
  "Shop",
  "Trainer’s Corner",
  "Recipes",
  "Why Proteem?",
  "About Us",
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Header */}
      <header className="relative z-30 bg-secondary py-3 px-4 sm:px-6">
        <div className="max-w-[1350px] mx-auto flex items-center justify-between">
          {/* Left: logo + hamburger on mobile */}
          <div className="flex items-center gap-3">
            {/* Hamburger (mobile only) */}
            <button
              aria-label="Open menu"
              onClick={() => setOpen(true)}
              className="lg:hidden p-1 rounded-md text-white hover:bg-white/10 transition"
            >
              {/* simple hamburger svg */}
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden
              >
                <path
                  d="M4 7h16M4 12h16M4 17h16"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Logos: show mobile logo on small screens, desktop logo on lg+ */}
            <div className="flex items-center">
              {/* Mobile logo */}
              <div className="block lg:hidden">
                <Image
                  src="/assets/logo-dark.png" // replace with /assets/logo-dark_mobile.png when you move to public/
                  alt="logo-dark_mobile"
                  width={100}
                  height={36}
                  className="object-contain w-20 "
                />
              </div>

              {/* Desktop logo */}
              <div className="hidden lg:block">
                <Image
                  src="/assets/logo-dark.png"
                  alt="logo-dark"
                  width={90}
                  height={40}
                  className="object-contain"
                />
              </div>
            </div>
          </div>

          {/* Center Nav (desktop only) */}
          <nav className="hidden lg:block">
            <ul className="flex items-center gap-6">
              {NAV_ITEMS.map((item, idx) => (
                <li key={idx}>
                  <Link
                    href="#"
                    className="text-[#E6F2F2] text-[14px] font-medium tracking-wide uppercase hover:text-white transition"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Search box: shrink on mobile */}
            <form className="hidden md:flex items-center bg-[#707070]  px-3 gap-2 h-9 w-[220px] lg:w-[369px]">
              <input
                type="text"
                placeholder="Search for products"
                className="text-[12px] font-normal text-white w-full outline-none placeholder:text-white pl-8 bg-[url('/assets/search_icon.png')] bg-no-repeat bg-left bg-size-[16px]"
              />
            </form>

            {/* On very small screens show an icon-only search button */}
            <button className="md:hidden bg-[#707070] p-2  text-white hover:bg-white/10 transition">
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden
              >
                <path
                  d="M21 21l-4.35-4.35"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <circle
                  cx="11"
                  cy="11"
                  r="6"
                  stroke="currentColor"
                  strokeWidth="2"
                />
              </svg>
            </button>

            {/* Login / Signup */}
            {/* <Link
              href="#"
              className="hidden md:flex items-center gap-2 bg-transparent text-white text-[12px] font-medium px-3 h-9 rounded-md border border-white"
            >
              <Image
                src="/assets/auth_icon.png"
                height={18}
                width={18}
                alt="auth"
              />
              <span className="whitespace-nowrap">Login / Signup</span>
            </Link> */}

            {/* Cart */}
            <Link
              href="#"
              className="flex items-center justify-center gap-2 bg-linear-to-b from-primary to-[#006662] text-white text-[12px] font-medium w-9 sm:max-w-[110px] sm:w-full sm:px-4 h-9  shadow-[0px_2px_6px_rgba(0,0,0,0.12)]"
            >
              <Image
                src="/assets/cart_icon.png"
                height={18}
                width={18}
                alt="cart"
              />
              <span className="whitespace-nowrap font-extrabold hidden sm:block">
                {" "}
                My Cart
              </span>
            </Link>
            <Link href="#" className="flex items-center gap-2 ">
              <Heart size={22} />
            </Link>
            <Link href="#" className="flex items-center gap-2">
              <LogIn size={22} />
            </Link>
          </div>
        </div>
      </header>

      {/* Sidebar + overlay */}
      <div
        aria-hidden={!open}
        className={`fixed inset-0 z-40 ${
          open ? "pointer-events-auto" : "pointer-events-none"
        }`}
      >
        {/* dim overlay (below panel) */}
        <div
          className={`absolute inset-0 bg-black/40 transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
          onClick={() => setOpen(false)}
        />

        {/* sliding panel: FIXED + higher z than overlay */}
        <aside
          className={`fixed top-0 left-0 h-full w-[80%] max-w-[360px] bg-secondary z-50 shadow-lg transform transition-transform duration-300
      ${open ? "translate-x-0" : "-translate-x-full"}`}
          role="dialog"
          aria-modal="true"
        >
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <div>
              <Image
                // example local test file path (replace with public path in production)
                src="/assets/logo-dark.png"
                alt="logo-dark_mobile"
                width={110}
                height={36}
                className="object-contain"
              />
            </div>
            <button
              aria-label="Close menu"
              onClick={() => setOpen(false)}
              className="p-2 rounded-md text-white hover:bg-white/10 transition"
            >
              {/* X icon */}
              <svg
                width="30"
                height="30"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden
              >
                <path
                  d="M18 6L6 18M6 6l12 12"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>

          <div className="p-4 space-y-4">
            {/* search */}
            {/* <form className="flex items-center bg-white rounded-md px-3 gap-2 h-10">
              <input
                type="text"
                placeholder="Search for products"
                className="text-[13px] text-[#333] w-full outline-none placeholder:text-[#757575] pl-8 bg-[url('/assets/search_icon.png')] bg-no-repeat bg-left bg-[length:16px]"
              />
            </form> */}

            {/* nav */}
            <nav>
              <ul className="flex flex-col gap-3">
                {NAV_ITEMS.map((item, idx) => (
                  <li key={idx}>
                    <Link
                      href="#"
                      onClick={() => setOpen(false)}
                      className="text-white text-[16px] font-medium block py-2 px-2 rounded hover:bg-white/10 transition"
                    >
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>

            {/* actions */}
            <div className="flex flex-col gap-3 pt-2">
              <Link
                href="#"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 bg-transparent text-white text-[14px] font-medium px-4 h-10 rounded-md border border-white"
              >
                <Image
                  src="/assets/auth_icon.png"
                  height={18}
                  width={18}
                  alt="auth"
                />
                Login / Signup
              </Link>

              {/* <Link
                href="#"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-[#F59A44] to-[#DD8B43] text-white text-[14px] font-medium px-4 h-10 rounded-md"
              >
                <Image
                  src="/assets/cart_icon.png"
                  height={18}
                  width={18}
                  alt="cart"
                />
                Cart
              </Link> */}
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
