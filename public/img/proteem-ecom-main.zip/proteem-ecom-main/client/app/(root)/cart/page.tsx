import {
  ArrowBigRight,
  ArrowRight,
  Heart,
  HeartPlus,
  Minus,
  Plus,
} from "lucide-react";
import Image from "next/image";
import React from "react";
import { FiTrash2 } from "react-icons/fi";

const CartPage = () => {
  return (
    <div className="min-h-screen bg-[linear-gradient(90deg,#F3F9F9_0%,#FFFFFF_50%,#F3F9F9_100%)] px-4 md:px-8 py-10">
      <div className="max-w-[1170px] w-full mx-auto px-5">
        {/* Page Title */}
        <div className="flex items-center justify-between mb-[40px]">
          <h1 className="text-2xl md:text-[48px] font-bold text-[#007F7B] ">
            Cart
          </h1>

          <button
            type="button"
            className="bg-[#E6F2F2] text-[#006662] text-[18px] font-semibold px-4 py-[7px] h-[48px] rounded-sm flex items-center justify-center gap-[10px]"
          >
            <HeartPlus size={20} />
            Save
          </button>
        </div>

        {/* Cart Items Container */}
        <div className="">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="flex items-center justify-between  border-b border-gray-200 p-4"
            >
              {/* Left: Image + Title */}
              <div className="flex items-center space-x-4">
                <div className="h-[72px] w-[72px]  rounded-lg ">
                  <Image
                    src="/assets/product_img1.png"
                    alt="product"
                    height={72}
                    width={72}
                    className="w-full h-[72px] object-cover border border-[#DDDDDD]"
                  />
                </div>
                <p className="text-[18px] font-regular text-gray-700 ">
                  Chocolate – Peanut Butter Protein Powder
                </p>
              </div>

              {/* Price */}
              <p className="text-[#757575] font-medium">$61.95</p>

              <p className="text-[#757575] text-[14px]">X</p>
              {/* Quantity Controls */}
              <div className="border-[#007F7B] border rounded-[8px]  overflow-hidden flex items-center h-[48px]  ">
                <button className="bg-[#E6F2F2] p-[12px] text-[#007F7B] h-[48px]">
                  <Minus size={14} />
                </button>
                <h6 className="py-[14px] px-[16px] text-[18px] text-black">
                  6
                </h6>
                <button className="bg-[#E6F2F2] p-[12px] text-[#007F7B] h-[48px]">
                  <Plus size={14} />
                </button>
              </div>
              <p className="text-[#757575] text-[18px]">=</p>
              {/* Total */}
              <p className="text-black text-[18px] font-semibold">$123.90</p>

              {/* Delete */}
              <button
                type="button"
                className="bg-[#E6F2F2] text-[#006662] text-[18px] font-semibold p-2.5  h-[40px] rounded-sm flex items-center justify-center gap-[10px]"
              >
                <FiTrash2 size={24} />
              </button>
            </div>
          ))}
        </div>

        {/* Checkout Bar */}
        <div className="">
          <button className="bg-[#007F7B] text-white px-6 rounded py-2 font-semibold hover:opacity-90 w-full flex justify-between mt-5 ">
            <span className="flex items-center gap-1">
              Checkout <ArrowRight size={16} />
            </span>{" "}
            <span className="font-bold text-white">$610.95</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
