import React from "react";
import Header from "@/app/_components/header";
import Footer from "@/app/_components/footer";

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="app_layout">
      <Header />
      {children}
      <Footer />
    </div>
  );
}

export default AppLayout;
