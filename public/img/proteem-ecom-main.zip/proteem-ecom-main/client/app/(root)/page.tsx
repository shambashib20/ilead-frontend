import Image from "next/image";
import ResponsiveImage from "../_components/image";
import Product from "../_components/product";
import { ProductContainer } from "../_components/ProductContainer";

export default function Home() {
  return (
    <>
      <section className="hero-sec relative z-0 px-2 sm:px-5 bg-secondary">
        <ResponsiveImage
          desktopSrc="/assets/hero_bg.png"
          mobileSrc="/assets/hero_bg-mobile.png"
          alt="Hero"
          width={1440}
          height={600}
          className="w-full h-auto"
        />

        <div className="content absolute top-0 left-0 sm:h-full h-full  w-full px-4 flex items-center justify-center ">
          <div className="max-w-[1170px] w-full mx-auto text-center ">
            <h1 className="md:text-white text-white  uppercase md:text-[48px] text-[20px] inline-flex flex-col  font-bold tracking-[2px] sm:leading-[64px] ">
              <div> Welcome to Proteem™ </div>{" "}
              <div> Proud Makers of Proteem™</div>
            </h1>

            <ul className="flex gap-6 items-center flex-col sm:flex-row mt-6 sm:mt-[80px] justify-center">
              <li>
                <button className="bg-primary text-white px-[28px] py-[12px] font-bold tracking-[2px] text-[16px] sm:text-[20px]">
                  {" "}
                  Shop Now
                </button>
              </li>
              <li>
                <button className="bg-secondary text-primary px-[28px] py-[12px] font-bold tracking-[2px]  text-[16px] sm:text-[20px] border border-primary sm:border-transparent rounded-md">
                  Read More
                </button>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* <section className="bg-white py-10 ">
        <div className="max-w-[1170px] w-full mx-auto px-5">
          <div className="text-center">
            <h2 className="md:text-[32px] text-[24px] md:max-w-full w-full max-w-[320px] mx-auto text-primary">
              {" "}
              <span className="font-semibold">
                Your Transformation Journey
              </span>{" "}
              Begins Here
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 md:gap-10 gap-4  auto-rows-[160px] md:auto-rows-[240px]">
            <article className="relative rounded-2xl overflow-hidden col-span-1 row-span-2 md:row-span-1">
              <div className="relative w-full h-full">
                <Image
                  src="/assets/item_img.png"
                  alt="Proteem shop"
                  fill
                  className="object-cover"
                  sizes="(max-width:640px) 100vw, 33vw"
                />
              </div>

              <div className="absolute inset-x-0 bottom-0 h-28 pointer-events-none">
                <div
                  style={{
                    background:
                      "linear-gradient(0deg, rgba(0,25,25,0.85) 100%, rgba(0,25,25,0) 70%)",
                    filter: "blur(22px)",
                    height: "100%",
                  }}
                  className="w-full"
                />
              </div>

              <h3 className="absolute z-10 bottom-4 left-1/2 -translate-x-1/2 text-white text-[16px] font-semibold uppercase text-center px-4 w-full">
                PROTEEM™ SHOP
              </h3>
            </article>

            <article className="relative rounded-2xl overflow-hidden">
              <div className="relative w-full h-full">
                <Image
                  src="/assets/item_img1.png"
                  alt="Trainer's shop"
                  fill
                  className="object-cover"
                  sizes="(max-width:640px) 50vw, 33vw"
                />
              </div>

              <div className="absolute inset-x-0 bottom-0 h-28 pointer-events-none">
                <div
                  style={{
                    background:
                      "linear-gradient(0deg, rgba(0,25,25,0.85) 100%, rgba(0,25,25,0) 70%)",
                    filter: "blur(22px)",
                    height: "100%",
                  }}
                  className="w-full"
                />
              </div>

              <h3 className=" w-full absolute z-10 bottom-4 left-1/2 -translate-x-1/2 text-white text-[16px] font-semibold uppercase text-center px-4">
                TRAINER{"'"}S Corner
              </h3>
            </article>

            <article className="relative rounded-2xl overflow-hidden">
              <div className="relative w-full h-full">
                <Image
                  src="/assets/item_img3.png"
                  alt="Proteem recipes"
                  fill
                  className="object-cover"
                  sizes="(max-width:640px) 50vw, 33vw"
                />
              </div>

              <div className="absolute inset-x-0 bottom-0 h-28 pointer-events-none">
                <div
                  style={{
                    background:
                      "linear-gradient(0deg, rgba(0,25,25,0.85) 100%, rgba(0,25,25,0) 70%)",
                    filter: "blur(22px)",
                    height: "100%",
                  }}
                  className="w-full"
                />
              </div>

              <h3 className="absolute z-10 bottom-4 left-1/2 -translate-x-1/2 text-white text-[16px] font-semibold uppercase text-center px-4 w-full">
                PROTEEM™ RECIPES
              </h3>
            </article>
          </div>
        </div>
      </section> */}

      <section className="bg-secondary py-[80px]">
        <div className="max-w-[1170px] w-full mx-auto px-5">
          <div className="grid grid-cols-2 md:grid-cols-3  gap-[40px]">
            <div className="col relative overflow-hidden rounded-[20px] md:col-span-2">
              <Image
                src="/assets/sec2-img1.png"
                alt="Proteem-shop"
                height={400}
                width={820}
                className="object-cover h-full w-full"
                sizes="(max-width:640px) 100vw, 33vw"
              />
              <h5 className=" clip1  font-bold p-5 w-[250px] text-white bg-primary absolute left-0 bottom-0">
                Proteem™ Shop
              </h5>
            </div>
            <div className="col relative overflow-hidden rounded-[20px]">
              <Image
                src="/assets/sec2-img1.png"
                alt="Proteem-shop"
                height={400}
                width={820}
                className="object-cover  h-full w-full object-[-240px_0px]"
                sizes="(max-width:640px) 100vw, 33vw"
              />
              <h5 className=" clip1  font-bold p-5 w-[250px] text-white bg-primary absolute left-0 bottom-0">
                Proteem™ Shop
              </h5>
            </div>
            <div className="col relative overflow-hidden rounded-[20px]">
              <Image
                src="/assets/sec2-img1.png"
                alt="Proteem-shop"
                height={400}
                width={820}
                className="object-cover  md:h-full w-full md:object-[-240px_0px]"
                sizes="(max-width:640px) 100vw, 33vw"
              />
              <h5 className=" clip1  font-bold p-5 w-[250px] text-white bg-primary absolute left-0 bottom-0">
                Proteem™ Shop
              </h5>
            </div>
            <div className="col relative overflow-hidden rounded-[20px] md:col-span-2">
              <Image
                src="/assets/sec2-img1.png"
                alt="Proteem-shop"
                height={400}
                width={820}
                className="object-cover  h-full w-full"
                sizes="(max-width:640px) 100vw, 33vw"
              />
              <h5 className=" clip1  font-bold p-5 w-[250px] text-white bg-primary absolute left-0 bottom-0">
                Proteem™ Shop
              </h5>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary py-10 ">
        <div className="max-w-[1170px] w-full mx-auto px-5">
          <div className="text-center mb-8">
            <h2 className="md:text-[48px] text-[24px] md:max-w-full w-full max-w-[320px] mx-auto text-white flex gap-3 items-center justify-center">
              <Image
                src="/assets/left_arm.png"
                width={90}
                height={100}
                className="w-[90px] h-[100px] mt-[-50px]"
                alt="left_arm"
              />
              Featured Products
              <Image
                src="/assets/right_arm.png"
                width={90}
                height={100}
                className="w-[90px] h-[100px]  mt-[-50px]"
                alt="right_arm"
              />
            </h2>
          </div>
          <div className="max-w-[100%] mx-auto">
            <ProductContainer>
              <article className=" rounded-2xl overflow-hidden">
                {" "}
                <Image
                  src={"/assets/cat1.png"}
                  height={330}
                  width={330}
                  alt={"cat1"}
                  className="w-[330px] h-[440px] object-cover"
                />
              </article>
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />

              <Product
                title="Vanilla Whey Isolate"
                price={49.95}
                image="/assets/product_img1.png"
              />
              <article className=" rounded-2xl overflow-hidden">
                {" "}
                <Image
                  src={"/assets/cat1.png"}
                  height={330}
                  width={330}
                  alt={"cat1"}
                  className="w-[330px] h-[440px] object-cover"
                />
              </article>
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Salted Caramel Protein Shake"
                price={59.95}
                image="/assets/product_img1.png"
              />
            </ProductContainer>
          </div>
        </div>
      </section>

      {/* <section className=" form-sec relative z-0">
        <ResponsiveImage
          desktopSrc="/assets/form_img.png"
          mobileSrc="/assets/form_img-mobile.png"
          alt="Hero"
          width={1440}
          height={500}
          className="w-full md:h-[500px] h-[300px]"
        />
     

        <div className="content absolute md:top-1/2 top-[63px]  left-1/2 -translate-x-1/2   md:-translate-y-1/2  w-full px-4 flex items-end ">
          <div className="max-w-[1170px] w-full mx-auto p-4 ">
            <div className="md:w-[500px] rounded-[8px] w-full md:p-[60px] px-[20px] py-[40px] bg-[#fef5ede8]">
              <h4
                className=" text-black md:font-normal font-medium  md:text-[28px] text-[20px] inline-flex flex-col
  md:mb-[60px] mb-5 pr-8 md:pr-0"
              >
                <span className="font-bold text-black">
                  Subscribe to our newsletter
                </span>
                and be the first to know latest updates and special discount
                offers.
              </h4>

              <form className="flex md:flex-row flex-col md:items-center items-start md:gap-2   gap-3.5 ">
                <input
                  type="text"
                  placeholder="e.g. john.doe@xyz.com"
                  className="text-[14px] font-normal text-[#333] bg-white rounded-md px-3 w-full outline-none placeholder:text-[#757575] h-10"
                />

                <button className="bg-primary text-[16px] font-semibold text-white px-4 py-2">
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </section> */}
    </>
  );
}
