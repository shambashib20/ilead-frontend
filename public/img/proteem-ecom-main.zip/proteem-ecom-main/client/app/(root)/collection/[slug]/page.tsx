import Product from "@/app/_components/product";
import { ProductContainer } from "@/app/_components/ProductContainer";
import { CircleAlert, Minus, Plus } from "lucide-react";
import Image from "next/image";
import React from "react";

function CollectionDetail() {
  const price = 54.95;
  const weight = "2.2 lbs";
  return (
    <>
      {" "}
      <section className="detail pt-[20px] bg-[linear-gradient(90deg,#F3F9F9_0%,#FFFFFF_50%,#F3F9F9_100%)]">
        <div className="max-w-[1170px] w-full mx-auto px-5">
          <div className="grid sm:grid-cols-2 grid-cols-1 gap-6 py-10">
            <div className="col">
              <Image
                src={"/assets/product_detail.png"}
                alt="product_img"
                height={700}
                width={554}
                className="w-full rounded"
              />
            </div>
            <div className="col">
              <h2 className="font-medium text-black text-[32px] leading-[48px] tracking-[2px]">
                Chocolate-Peanut Butter Protein Powder
              </h2>

              <div className="flex gap-[20px] items-center mt-[12px] ">
                <h4 className="text-[#DD8B43] text-[28px] font-bold">
                  {typeof price === "number" ? `$${price.toFixed(2)}` : price}
                </h4>

                <h5 className="flex items-center gap-1.5 bg-[#FDEBDB] text-[16px] leading-[0.5] text-black px-3 py-[7px] ">
                  <Image
                    src="/assets/weight_icon.png"
                    alt="weight icon"
                    width={16}
                    height={16}
                  />
                  <span>{weight}</span>
                </h5>
              </div>
              <div className="flex gap-[20px] items-center mt-[28px]">
                <h4 className="text-[18px] font-semibold text-black">
                  Select Flavour{" "}
                </h4>
                <select
                  name=""
                  id=""
                  className="h-[48px] bg-[#E6F2F2] text-[18px] text-black py-[14px] px-[16px] pe-[24px] "
                >
                  <option value="">Choclate Peanut Butter</option>
                </select>
              </div>

              <div className=" flex gap-[14px] my-[28px]">
                <ul className="flex md:flex-row flex-col mt-3 space-x-[14px] w-full items-center">
                  <li className="">
                    <div className="border-[#007F7B] border rounded-[8px]  overflow-hidden flex items-center h-[48px]  ">
                      <button className="bg-[#E6F2F2] p-[12px] text-[#007F7B]">
                        <Minus />
                      </button>
                      <h6 className="py-[14px] px-[16px] text-[18px] text-black">
                        6
                      </h6>
                      <button className="bg-[#E6F2F2] p-[12px] text-[#007F7B]">
                        <Plus />
                      </button>
                    </div>
                  </li>
                  <li className="md:flex-1 flex-none">
                    <button
                      type="button"
                      className="bg-[#E6F2F2] text-[#006662] text-[18px] font-semibold px-1.5 py-[7px] h-[48px] rounded-sm flex items-center justify-center gap-1.5 w-full"
                    >
                      <Image
                        src="/assets/cart_icon2.png"
                        alt="add to cart icon"
                        width={22}
                        height={22}
                      />
                      Add to Cart
                    </button>
                  </li>

                  <li className="md:flex-1 flex-none">
                    <button
                      type="button"
                      className="text-[#E6F2F2] text-[18px] font-semibold bg-[#006662] px-1.5 py-[7px] h-[48px] rounded-sm flex items-center justify-center gap-1.5 w-full"
                    >
                      <Image
                        src="/assets/fast_icon.png"
                        alt="buy now icon"
                        width={22}
                        height={22}
                      />
                      Buy Now
                    </button>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px] pb-[14px] border-b border-[#DDDDDD] pt-[14px] ">
                  <CircleAlert className="mt-2" />
                  <span className="flex   flex-col  ">
                    {" "}
                    Product Overview
                    <span className="text-[18px] text-black font-normal">
                      24g Protein, 11g Carbs, 3.5g Fat per scoop
                    </span>
                  </span>
                </h4>

                <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px] pb-[14px] border-b border-[#DDDDDD] pt-[14px] ">
                  <CircleAlert className="mt-2" />
                  <span className="flex   flex-col  ">
                    {" "}
                    Key Benefits
                    <ul className="flex flex-col">
                      <li className="text-[18px] text-black font-normal list-disc">
                        Meal replacement
                      </li>
                      <li className="text-[18px] text-black font-normal list-disc">
                        Post-workout recovery
                      </li>
                    </ul>
                  </span>
                </h4>

                <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px] pb-[14px] border-b border-[#DDDDDD] pt-[14px] ">
                  <CircleAlert className="mt-2" />
                  <span className="flex   flex-col  ">
                    {" "}
                    How to Use
                    <span className="text-[18px] text-black font-normal">
                      Mix 1 scoop with water or milk post-workout or as a meal
                      replacement
                    </span>
                  </span>
                </h4>

                <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px] pb-[14px] border-b border-[#DDDDDD] pt-[14px] ">
                  <CircleAlert className="mt-2" />
                  <span className="flex   flex-col  ">
                    {" "}
                    Ingredients
                    <ul className="flex flex-col">
                      <li className="text-[18px] text-black font-normal list-disc">
                        Whey Protein Isolate
                      </li>
                      <li className="text-[18px] text-black font-normal list-disc">
                        Cocoa
                      </li>
                      <li className="text-[18px] text-black font-normal list-disc">
                        Sweeteners
                      </li>
                      <li className="text-[18px] text-black font-normal list-disc">
                        Peanut Flour
                      </li>
                    </ul>
                  </span>
                </h4>

                <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px] pb-[14px] border-b border-[#DDDDDD] pt-[14px] ">
                  <CircleAlert className="mt-2" />
                  <span className="flex   flex-col  ">
                    {" "}
                    Training Type
                    <span className="text-[18px] text-black font-normal">
                      Best for athletes and bodybuilders
                    </span>
                  </span>
                </h4>
                <div className="border-b border-[#DDDDDD] pt-[14px] pb-[14px]">
                  <h4 className="text-[#007F7B] text-[24px] flex items-start gap-[10px]  ">
                    <CircleAlert className="mt-2" />
                    <span className="flex   flex-col  "> Training Type</span>
                  </h4>
                  <div>
                    <ul className="ps-[38px] space-y-[14px] mt-[10px]">
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Flavor(s)
                        </span>{" "}
                        Chocolate-Peanut Butter
                      </li>
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Serving Size
                        </span>{" "}
                        1 Scoop (34g)
                      </li>
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Servings per Container
                        </span>{" "}
                        32 servings
                      </li>
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Allergen
                        </span>{" "}
                        Contains Milk, Peanuts and Soy (Lecithin)
                      </li>

                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Certifications
                        </span>{" "}
                        GMP certified
                      </li>
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Made in
                        </span>{" "}
                        USA
                      </li>
                      <li className="grid grid-cols-2 text-[18px] text-black font-normal">
                        <span className="text-[#757575] text-[18px]">
                          Storage
                        </span>{" "}
                        Store in a cool, dry place
                      </li>
                    </ul>
                  </div>
                </div>

                <h6 className="text-[11px] italic font-extralight text-black py-[10px]">
                  These statements have not been evaluated by the FDA. This
                  product is intended for use as a dietary supplement only. Not
                  for weight reduction. Keep out of reach of children. Consult a
                  physician if pregnant or nursing.
                </h6>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="pb-[60px] bg-[linear-gradient(90deg,#F3F9F9_0%,#FFFFFF_50%,#F3F9F9_100%)]">
        <div className="max-w-[1170px] w-full mx-auto px-5">
          <div className="text-center mb-8">
            <h2 className="md:text-[32px] text-[24px] md:max-w-full w-full max-w-[320px] mx-auto text-primary">
              {" "}
              <span className="font-semibold">Related</span> Products
            </h2>
          </div>

          <div className=" ">
            <ProductContainer>
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
            </ProductContainer>
          </div>
        </div>
      </section>
    </>
  );
}

export default CollectionDetail;
