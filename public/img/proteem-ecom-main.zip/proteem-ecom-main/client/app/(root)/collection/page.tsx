import React from "react";
import { ArrowUpDown } from "lucide-react";
import Product from "@/app/_components/product";
import { ProductContainer } from "@/app/_components/ProductContainer";

function CollectionPage() {
  return (
    <section className="bg-[linear-gradient(90deg,#F3F9F9_0%,#FFFFFF_50%,#F3F9F9_100%)] sm:pt-[60px] pb-[25px">
      <div className="max-w-[1168px] mx-auto ">
        <div className="sm:h-[243px] h-[74px] bg-[#DDDDDD]"></div>
      </div>

      <div className="product-table">
        <div className="max-w-[1168px] mx-auto px-[20px]">
          <div>
            <button className="border-[#007F7B] font-medium border text-black py-[6px] px-[10px] capitalize rounded-[4px] my-[24px] flex items-center gap-2">
              <ArrowUpDown size={15} /> Sort by:{" "}
              <span className="uppercase font-semibold text-[#007F7B]">
                {" "}
                PRICE - LOW TO HIGH
              </span>
            </button>
          </div>
          <div className=" pb-[60px]">
            <ProductContainer>
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Vanilla Protein Powder"
                price={49.95}
                image="/assets/product_img2.png"
              />
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Vanilla Protein Powder"
                price={49.95}
                image="/assets/product_img2.png"
              />
              <Product
                title="Vanilla Protein Powder"
                price={49.95}
                image="/assets/product_img2.png"
              />
              <Product
                title="Chocolate – Peanut Butter Protein Powder"
                price={54.95}
                image="/assets/product_img1.png"
              />
              <Product
                title="Vanilla Protein Powder"
                price={49.95}
                image="/assets/product_img2.png"
              />
            </ProductContainer>
          </div>
        </div>
      </div>
    </section>
  );
}

export default CollectionPage;
