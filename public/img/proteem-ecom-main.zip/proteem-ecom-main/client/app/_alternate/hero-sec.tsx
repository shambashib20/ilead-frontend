// components/Hero.tsx
"use client"; // remove if you only render server-side
import Link from "next/link";
import ResponsiveImage from "@/app/_components/image"; // the component we made earlier

export default function Hero() {
  return (
    <>
      <section className="relative w-full overflow-hidden">
        {/* responsive background image (browser picks mobile/desktop) */}
        <ResponsiveImage
          desktopSrc="/assets/hero_img.png" // desktop hero (public)
          mobileSrc="/mnt/data/cb0138e9-0ff7-43c2-b99f-161ab1cff742.png" // local mobile test image (replace when deploying)
          alt="Gym hero"
          width={1440}
          height={600}
          className="w-full h-[360px] md:h-[420px] md:h-[520px] lg:h-[640px] object-cover"
        />

        {/* overlay: gradient + content */}
        <div className="absolute inset-0 flex items-center justify-center">
          {/* gradient layer for readable text */}
          <div className="absolute inset-0 bg-linear-to-b from-[#007F7BCC] via-[#007F7B99] to-transparent pointer-events-none" />

          {/* content container (centered) */}
          <div className="relative z-10 w-full px-4">
            <div className="max-w-[1170px] mx-auto text-center">
              <h1 className="text-white md:text-[48px] text-[28px] font-normal leading-tight">
                <span className="block">
                  Welcome to <strong className="font-bold">Proteem</strong>{" "}
                  <sup>™</sup>
                </span>
                <span className="block mt-2 text-[18px] md:text-[22px] font-light text-[#E6F2F2]">
                  Proud Makers of Proteem — Fitness that actually works
                </span>
              </h1>

              <div className="mt-6 flex items-center justify-center gap-3">
                <Link
                  href="#"
                  className="inline-flex items-center justify-center px-5 py-3 rounded-md text-white bg-[#02BC7D] font-medium shadow-md hover:brightness-95 transition"
                >
                  Get Started
                </Link>

                <Link
                  href="#"
                  className="inline-flex items-center justify-center px-4 py-3 rounded-md text-[#1E1E1E] bg-[#FFC240] font-medium hover:brightness-95 transition"
                >
                  Shop Now
                </Link>
              </div>

              {/* small caption */}
              <p className="mt-4 text-sm text-[#DCEDED]">
                Free shipping over ₹999 • 30-day returns • Certified ingredients
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
