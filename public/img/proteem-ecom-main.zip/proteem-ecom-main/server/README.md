# Proteem E-commerce Backend

FastAPI backend for the Proteem E-commerce site

## Tech Stack

- FastAPI + Uvicorn (ORJSON responses)
- MongoDB + Beanie ODM
- Pydantic v2 + pydantic-settings
- JWT auth (python-jose + bcrypt)
- PayPal integration (httpx)

## Project Structure

```
app/
├── main.py           # App factory & root routes
├── config.py         # Settings (pydantic-settings)
├── database.py       # MongoDB connection
├── api/
│   ├── deps.py       # Auth dependencies
│   └── v1/           # API routes
├── models/           # Beanie document models
├── schemas/          # Pydantic request/response schemas
├── services/         # Business logic
├── core/             # Middleware, logging, lifecycle
└── utils/            # Security, PayPal client, helpers
```

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Configure MongoDB, JWT secret, PayPal keys
uvicorn app.main:app --reload
```

## API Endpoints

### Service
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Service info & API groups |
| GET | `/health` | Health check |

### Authentication (`/api/v1/auth`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/register` | Register new user |
| POST | `/login` | Login (returns JWT + sets cookies) |
| POST | `/refresh` | Refresh access token |
| POST | `/logout` | Clear auth cookies |

### Users (`/api/v1/users`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/me` | Get current user profile |
| PUT | `/me` | Update current user profile |

### Products (`/api/v1/products`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | List products (filter, sort, paginate) |
| GET | `/featured` | Get featured products |
| GET | `/{slug}` | Get product by slug |
| GET | `/related/{slug}` | Get related products |
| POST | `/` | Create product (admin) |
| PUT | `/{product_id}` | Update product (admin) |
| DELETE | `/{product_id}` | Delete product (admin) |

### Categories (`/api/v1/categories`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | List categories |
| GET | `/{slug}` | Get category with products |
| POST | `/` | Create category (admin) |

### Cart (`/api/v1/cart`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Get cart |
| POST | `/` | Add item to cart |
| PUT | `/{item_id}` | Update item quantity |
| DELETE | `/{item_id}` | Remove item |
| DELETE | `/` | Clear cart |

### Wishlist (`/api/v1/wishlist`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Get wishlist |
| POST | `/` | Add to wishlist |
| DELETE | `/{item_id}` | Remove from wishlist |
| POST | `/move-to-cart/{item_id}` | Move item to cart |

### Orders (`/api/v1/orders`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | List user orders |
| GET | `/{order_id}` | Get order details |
| POST | `/` | Create order from cart |
| PUT | `/{order_id}/cancel` | Cancel order |
| PUT | `/{order_id}/status` | Update status (admin) |

### Payments (`/api/v1/payments`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/config` | Get PayPal client config |
| POST | `/paypal/order` | Create PayPal order |
| POST | `/paypal/capture` | Capture approved payment |
| GET | `/paypal/order/{id}` | Get PayPal order status |
| POST | `/paypal/refund/{order_id}` | Refund payment (admin) |

### Newsletter (`/api/v1/newsletter`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/subscribe` | Subscribe to newsletter |

### Search (`/api/v1/search`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Search products |

## Docs

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc
