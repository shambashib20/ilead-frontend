from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.database import close_mongo_connection, connect_to_mongo


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan hook to manage startup and shutdown tasks."""
    await connect_to_mongo()
    yield
    await close_mongo_connection()
