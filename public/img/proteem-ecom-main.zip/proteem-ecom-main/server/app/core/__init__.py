"""Core package for application-wide configuration, middleware, and utilities."""

from app.config import settings

__all__ = ["settings"]
