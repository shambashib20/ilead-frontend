import re
from slugify import slugify as python_slugify
import uuid


def generate_slug(text: str) -> str:
    """Generate URL-friendly slug from text"""
    return python_slugify(text, lowercase=True)


def generate_unique_slug(text: str) -> str:
    """Generate unique slug with short UUID suffix"""
    base_slug = generate_slug(text)
    unique_suffix = str(uuid.uuid4())[:8]
    return f"{base_slug}-{unique_suffix}"


def generate_order_number() -> str:
    """Generate unique order number"""
    import random
    import string
    from datetime import datetime
    
    date_part = datetime.utcnow().strftime("%Y%m%d")
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"ORD-{date_part}-{random_part}"


def format_price(price: float) -> str:
    """Format price for display"""
    return f"${price:.2f}"


def calculate_cart_total(items: list) -> dict:
    """Calculate cart totals"""
    # Round each item's total to avoid floating point issues
    subtotal = round(sum(round(item.unit_price * item.quantity, 2) for item in items), 2)
    tax = round(subtotal * 0.0825, 2)  # Example: 8.25% tax
    shipping = 0.00  # Free shipping or calculated separately
    total = round(subtotal + tax + shipping, 2)
    
    return {
        "subtotal": subtotal,
        "tax": tax,
        "shipping": shipping,
        "total": total,
        "items_count": len(items),
        "total_quantity": sum(item.quantity for item in items),
    }
