"""
PayPal REST API v2 Integration

This module handles all PayPal payment operations including:
- OAuth 2.0 authentication
- Creating PayPal orders
- Capturing payments
- Getting order details
- Handling refunds

PayPal API Documentation: https://developer.paypal.com/docs/api/orders/v2/
"""

import httpx
import base64
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from app.config import settings


class PayPalClient:
    """PayPal API Client for REST API v2"""
    
    def __init__(self):
        self.client_id = settings.paypal_client_id
        self.client_secret = settings.paypal_client_secret
        self.base_url = settings.paypal_base_url
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
    
    async def _get_access_token(self) -> str:
        """Get OAuth 2.0 access token from PayPal"""
        # Return cached token if still valid
        if self._access_token and self._token_expires_at:
            if datetime.utcnow() < self._token_expires_at:
                return self._access_token
        
        # Get new token
        auth_string = f"{self.client_id}:{self.client_secret}"
        auth_bytes = auth_string.encode("utf-8")
        auth_base64 = base64.b64encode(auth_bytes).decode("utf-8")
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/v1/oauth2/token",
                headers={
                    "Authorization": f"Basic {auth_base64}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data={"grant_type": "client_credentials"},
            )
            
            if response.status_code != 200:
                raise PayPalError(f"Failed to get access token: {response.text}")
            
            data = response.json()
            self._access_token = data["access_token"]
            # Expire 5 minutes early to be safe
            expires_in = data.get("expires_in", 3600) - 300
            self._token_expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
            
            return self._access_token
    
    async def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Make authenticated request to PayPal API"""
        access_token = await self._get_access_token()
        
        default_headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        
        if headers:
            default_headers.update(headers)
        
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=f"{self.base_url}{endpoint}",
                headers=default_headers,
                json=data,
            )
            
            if response.status_code >= 400:
                raise PayPalError(
                    f"PayPal API error ({response.status_code}): {response.text}"
                )
            
            if response.status_code == 204:
                return {}
            
            return response.json()
    
    async def create_order(
        self,
        amount: float,
        currency: str = "USD",
        items: Optional[List[Dict[str, Any]]] = None,
        shipping_address: Optional[Dict[str, Any]] = None,
        reference_id: Optional[str] = None,
        description: Optional[str] = None,
        tax_total: Optional[float] = None,
        shipping_total: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Create a PayPal order for checkout
        
        Args:
            amount: Total order amount
            currency: Currency code (default: USD)
            items: List of item details for line-item display
            shipping_address: Shipping address details
            reference_id: Your internal order reference
            description: Order description
            tax_total: Tax amount
            shipping_total: Shipping cost
            
        Returns:
            PayPal order response with order ID and approval URL
        """
        purchase_unit: Dict[str, Any] = {
            "amount": {
                "currency_code": currency,
                "value": f"{amount:.2f}",
            },
        }
        
        if reference_id:
            purchase_unit["reference_id"] = reference_id
        
        if description:
            purchase_unit["description"] = description
        
        # Add item breakdown if items provided
        # PayPal requires: amount.value == item_total + tax_total + shipping + handling + insurance - shipping_discount - discount
        if items:
            item_total = sum(float(item.get("unit_amount", {}).get("value", 0)) * int(item.get("quantity", 1)) for item in items)
            
            breakdown: Dict[str, Any] = {
                "item_total": {
                    "currency_code": currency,
                    "value": f"{item_total:.2f}",
                },
            }
            
            # Add tax if provided
            if tax_total is not None and tax_total > 0:
                breakdown["tax_total"] = {
                    "currency_code": currency,
                    "value": f"{tax_total:.2f}",
                }
            
            # Add shipping if provided
            if shipping_total is not None and shipping_total > 0:
                breakdown["shipping"] = {
                    "currency_code": currency,
                    "value": f"{shipping_total:.2f}",
                }
            
            purchase_unit["amount"]["breakdown"] = breakdown
            purchase_unit["items"] = items
        
        # Add shipping address if provided
        if shipping_address:
            purchase_unit["shipping"] = {
                "address": shipping_address,
            }
        
        order_data = {
            "intent": "CAPTURE",
            "purchase_units": [purchase_unit],
            "application_context": {
                "brand_name": "Proteem",
                "landing_page": "NO_PREFERENCE",
                "user_action": "PAY_NOW",
                "return_url": f"{settings.frontend_url}/checkout/success",
                "cancel_url": f"{settings.frontend_url}/checkout/cancel",
            },
        }
        
        response = await self._make_request("POST", "/v2/checkout/orders", data=order_data)
        return response
    
    async def capture_order(self, order_id: str) -> Dict[str, Any]:
        """
        Capture payment for an approved PayPal order
        
        This should be called after the customer approves the payment
        on PayPal's side. The order must be in "APPROVED" status.
        
        Args:
            order_id: The PayPal order ID
            
        Returns:
            Capture response with payment details
        """
        response = await self._make_request(
            "POST",
            f"/v2/checkout/orders/{order_id}/capture",
        )
        return response
    
    async def get_order(self, order_id: str) -> Dict[str, Any]:
        """
        Get PayPal order details
        
        Args:
            order_id: The PayPal order ID
            
        Returns:
            Order details including status, amounts, and payer info
        """
        response = await self._make_request(
            "GET",
            f"/v2/checkout/orders/{order_id}",
        )
        return response
    
    async def refund_capture(
        self,
        capture_id: str,
        amount: Optional[float] = None,
        currency: str = "USD",
        note: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Refund a captured payment
        
        Args:
            capture_id: The capture ID from the payment
            amount: Refund amount (None for full refund)
            currency: Currency code
            note: Note to the payer about the refund
            
        Returns:
            Refund response with refund ID and status
        """
        data: Dict[str, Any] = {}
        
        if amount is not None:
            data["amount"] = {
                "value": f"{amount:.2f}",
                "currency_code": currency,
            }
        
        if note:
            data["note_to_payer"] = note
        
        response = await self._make_request(
            "POST",
            f"/v2/payments/captures/{capture_id}/refund",
            data=data if data else None,
        )
        return response


class PayPalError(Exception):
    """PayPal API Error"""
    pass


# Singleton instance
paypal_client = PayPalClient()
