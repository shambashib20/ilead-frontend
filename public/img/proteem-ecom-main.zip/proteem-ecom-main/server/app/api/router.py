from fastapi import APIRouter

from app.api.v1.router import api_router as v1_router

api_router = APIRouter()

# Mount versioned routers here (v1, v2, ...)
api_router.include_router(v1_router)

__all__ = ["api_router"]
