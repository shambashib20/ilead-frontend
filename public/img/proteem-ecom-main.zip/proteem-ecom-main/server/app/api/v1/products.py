from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from app.models.user import User
from app.schemas.product import (
    ProductCardResponse,
    ProductCreate,
    ProductDetailResponse,
    ProductListResponse,
    ProductUpdate,
)
from app.api.deps import get_current_admin
from app.services import product_service

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("", response_model=ProductListResponse)
async def list_products(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    category: Optional[str] = None,
    featured: Optional[bool] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    sort_by: str = Query("newest", regex="^(newest|price_asc|price_desc|name)$"),
    search: Optional[str] = None,
):
    """List products with filtering, sorting, and pagination"""
    return await product_service.list_products(
        page=page,
        page_size=page_size,
        category=category,
        featured=featured,
        min_price=min_price,
        max_price=max_price,
        sort_by=sort_by,
        search=search,
    )


@router.get("/featured", response_model=list[ProductCardResponse])
async def get_featured_products(limit: int = Query(8, ge=1, le=20)):
    """Get featured products for homepage"""
    return await product_service.get_featured_products(limit)


@router.get("/{slug}", response_model=ProductDetailResponse)
async def get_product_by_slug(slug: str):
    """Get product details by slug"""
    return await product_service.get_product_by_slug(slug)


@router.get("/related/{slug}", response_model=list[ProductCardResponse])
async def get_related_products(slug: str, limit: int = Query(4, ge=1, le=10)):
    """Get related products by category"""
    return await product_service.get_related_products(slug, limit)


# ==================== Admin Routes ====================
@router.post("", response_model=ProductDetailResponse, status_code=status.HTTP_201_CREATED)
async def create_product(
    product_data: ProductCreate,
    admin: User = Depends(get_current_admin)
):
    """Create a new product (admin only)"""
    return await product_service.create_product(product_data)


@router.put("/{product_id}", response_model=ProductDetailResponse)
async def update_product(
    product_id: str,
    product_data: ProductUpdate,
    admin: User = Depends(get_current_admin)
):
    """Update a product (admin only)"""
    return await product_service.update_product(product_id, product_data)


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(
    product_id: str,
    admin: User = Depends(get_current_admin)
):
    """Delete a product (admin only)"""
    await product_service.delete_product(product_id)
