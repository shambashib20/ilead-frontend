from fastapi import APIRouter
from app.api.v1.auth import router as auth_router
from app.api.v1.users import router as users_router
from app.api.v1.products import router as products_router
from app.api.v1.categories import router as categories_router
from app.api.v1.cart import router as cart_router, wishlist_router
from app.api.v1.orders import router as orders_router
from app.api.v1.newsletter import router as newsletter_router
from app.api.v1.search import router as search_router
from app.api.v1.payments import router as payments_router

api_router = APIRouter(prefix="/api/v1")

# Include all routers
api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(products_router)
api_router.include_router(categories_router)
api_router.include_router(cart_router)
api_router.include_router(wishlist_router)
api_router.include_router(orders_router)
api_router.include_router(newsletter_router)
api_router.include_router(search_router)
api_router.include_router(payments_router)
