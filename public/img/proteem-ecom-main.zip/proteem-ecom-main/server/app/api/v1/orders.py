from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from app.models.user import User
from app.schemas.order import OrderCreate, OrderResponse, OrdersListResponse
from app.api.deps import get_current_user, get_current_admin
from app.services import order_service

router = APIRouter(prefix="/orders", tags=["Orders"])


@router.get("", response_model=OrdersListResponse)
async def list_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=50),
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user)
):
    """List current user's orders"""
    return await order_service.list_orders_for_user(
        current_user, page=page, page_size=page_size, status_filter=status
    )


@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get order details"""
    return await order_service.get_order_detail(order_id, current_user)


@router.post("", response_model=OrderResponse, status_code=status.HTTP_201_CREATED)
async def create_order(
    order_data: OrderCreate,
    current_user: User = Depends(get_current_user)
):
    """Create order from cart"""
    return await order_service.create_order_from_cart(order_data, current_user)


@router.put("/{order_id}/cancel", response_model=OrderResponse)
async def cancel_order(
    order_id: str,
    current_user: User = Depends(get_current_user)
):
    """Cancel an order"""
    return await order_service.cancel_order(order_id, current_user)


# ==================== Admin Routes ====================
@router.put("/{order_id}/status", response_model=OrderResponse)
async def update_order_status(
    order_id: str,
    new_status: str,
    tracking_number: Optional[str] = None,
    admin: User = Depends(get_current_admin)
):
    """Update order status (admin only)"""
    return await order_service.update_order_status(order_id, new_status, tracking_number)
