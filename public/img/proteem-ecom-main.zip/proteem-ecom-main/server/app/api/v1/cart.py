from fastapi import APIRouter, Depends, status
from app.models.user import User
from app.schemas.cart import CartItemAdd, CartItemResponse, CartItemUpdate, CartResponse, WishlistItemAdd, WishlistItemResponse, WishlistResponse
from app.api.deps import get_current_user
from app.services import cart_service

router = APIRouter(prefix="/cart", tags=["Cart"])


@router.get("", response_model=CartResponse)
async def get_cart(current_user: User = Depends(get_current_user)):
    """Get current user's cart"""
    return await cart_service.get_cart_for_user(str(current_user.id))


@router.post("", response_model=CartItemResponse, status_code=status.HTTP_201_CREATED)
async def add_to_cart(
    item_data: CartItemAdd,
    current_user: User = Depends(get_current_user)
):
    """Add item to cart"""
    return await cart_service.add_item_to_cart(str(current_user.id), item_data)


@router.put("/{item_id}", response_model=CartItemResponse)
async def update_cart_item(
    item_id: str,
    item_data: CartItemUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update cart item quantity"""
    return await cart_service.update_cart_item(str(current_user.id), item_id, item_data)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_from_cart(
    item_id: str,
    current_user: User = Depends(get_current_user)
):
    """Remove item from cart"""
    await cart_service.remove_cart_item(str(current_user.id), item_id)


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
async def clear_cart(current_user: User = Depends(get_current_user)):
    """Clear all items from cart"""
    await cart_service.clear_cart(str(current_user.id))


# ==================== Wishlist Routes ====================
wishlist_router = APIRouter(prefix="/wishlist", tags=["Wishlist"])


@wishlist_router.get("", response_model=WishlistResponse)
async def get_wishlist(current_user: User = Depends(get_current_user)):
    """Get current user's wishlist"""
    return await cart_service.get_wishlist(str(current_user.id))


@wishlist_router.post("", response_model=WishlistItemResponse, status_code=status.HTTP_201_CREATED)
async def add_to_wishlist(
    item_data: WishlistItemAdd,
    current_user: User = Depends(get_current_user)
):
    """Add item to wishlist"""
    return await cart_service.add_to_wishlist(str(current_user.id), item_data)


@wishlist_router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_from_wishlist(
    item_id: str,
    current_user: User = Depends(get_current_user)
):
    """Remove item from wishlist"""
    await cart_service.remove_from_wishlist(str(current_user.id), item_id)


@wishlist_router.post("/move-to-cart/{item_id}", response_model=CartItemResponse)
async def move_to_cart(
    item_id: str,
    current_user: User = Depends(get_current_user)
):
    """Move item from wishlist to cart"""
    return await cart_service.move_wishlist_item_to_cart(str(current_user.id), item_id)
