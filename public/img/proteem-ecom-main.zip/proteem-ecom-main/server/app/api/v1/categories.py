from fastapi import APIRouter, Depends, status
from app.models.user import User
from app.schemas.product import CategoryCreate, CategoryResponse, CategoryUpdate
from app.api.deps import get_current_admin
from app.services import product_service

router = APIRouter(prefix="/categories", tags=["Categories"])


@router.get("", response_model=list[CategoryResponse])
async def list_categories():
    """List all active categories"""
    return await product_service.list_categories()


@router.get("/{slug}", response_model=CategoryResponse)
async def get_category(slug: str):
    """Get category by slug"""
    return await product_service.get_category(slug)


# ==================== Admin Routes ====================
@router.post("", response_model=CategoryResponse, status_code=status.HTTP_201_CREATED)
async def create_category(
    category_data: CategoryCreate,
    admin: User = Depends(get_current_admin)
):
    """Create a new category (admin only)"""
    return await product_service.create_category(category_data)


@router.put("/{category_id}", response_model=CategoryResponse)
async def update_category(
    category_id: str,
    category_data: CategoryUpdate,
    admin: User = Depends(get_current_admin)
):
    """Update a category (admin only)"""
    return await product_service.update_category(category_id, category_data)


@router.delete("/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_category(
    category_id: str,
    admin: User = Depends(get_current_admin)
):
    """Delete a category (admin only)"""
    await product_service.delete_category(category_id)
