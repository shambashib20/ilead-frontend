from typing import Literal, Optional

from fastapi import APIRouter, Cookie, HTTPException, Response, status

from app.schemas.user import (
    RefreshTokenRequest,
    TokenResponse,
    UserCreate,
    UserLogin,
    UserResponse,
)
from app.services import auth_service
from app.config import get_settings

settings = get_settings()
router = APIRouter(prefix="/auth", tags=["Authentication"])


def set_auth_cookies(response: Response, access_token: str, refresh_token: str):
    """Set authentication cookies on the response"""
    samesite: Literal["lax", "strict", "none"] = settings.cookie_samesite  # type: ignore
    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=settings.access_token_expire_minutes * 60,
        httponly=settings.cookie_httponly,
        secure=settings.cookie_secure,
        samesite=samesite,
        domain=settings.cookie_domain or None,
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        max_age=settings.refresh_token_expire_days * 24 * 60 * 60,
        httponly=settings.cookie_httponly,
        secure=settings.cookie_secure,
        samesite=samesite,
        domain=settings.cookie_domain or None,
    )


def clear_auth_cookies(response: Response):
    """Clear authentication cookies"""
    response.delete_cookie(key="access_token", domain=settings.cookie_domain or None)
    response.delete_cookie(key="refresh_token", domain=settings.cookie_domain or None)


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(user_data: UserCreate, response: Response):
    """Register a new user"""
    user = await auth_service.register_user(user_data)
    access_token, refresh_token = auth_service.issue_tokens_for_user(user)
    set_auth_cookies(response, access_token, refresh_token)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=UserResponse(**user.to_response()),
    )


@router.post("/login", response_model=TokenResponse)
async def login(credentials: UserLogin, response: Response):
    """Login user and return tokens"""
    user = await auth_service.authenticate_user(credentials)
    access_token, refresh_token = auth_service.issue_tokens_for_user(user)
    set_auth_cookies(response, access_token, refresh_token)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=UserResponse(**user.to_response()),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    request: RefreshTokenRequest,
    response: Response,
    refresh_token_cookie: Optional[str] = Cookie(default=None, alias="refresh_token"),
):
    """Refresh access token using provided refresh token or cookie fallback."""
    token = request.refresh_token or refresh_token_cookie
    if not token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Refresh token missing",
        )

    user = await auth_service.refresh_tokens(token)
    access_token, new_refresh_token = auth_service.issue_tokens_for_user(user)
    set_auth_cookies(response, access_token, new_refresh_token)

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh_token,
        user=UserResponse(**user.to_response()),
    )


@router.post("/logout")
async def logout(response: Response):
    """Logout user by clearing auth cookies"""
    clear_auth_cookies(response)
    return {"message": "Successfully logged out"}
