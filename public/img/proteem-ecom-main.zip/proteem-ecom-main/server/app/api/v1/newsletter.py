from datetime import datetime
from fastapi import APIRouter, HTTPException, status
from app.models.newsletter import NewsletterSubscriber
from app.schemas.common import NewsletterSubscribe, NewsletterResponse

router = APIRouter(prefix="/newsletter", tags=["Newsletter"])


@router.post("/subscribe", response_model=NewsletterResponse)
async def subscribe_to_newsletter(data: NewsletterSubscribe):
    """Subscribe to newsletter"""
    existing = await NewsletterSubscriber.find_one(NewsletterSubscriber.email == data.email)

    if existing:
        if existing.is_active:
            return NewsletterResponse(message="Already subscribed", email=data.email)
        else:
            existing.is_active = True
            existing.unsubscribed_at = None
            await existing.save()
            return NewsletterResponse(message="Subscription reactivated", email=data.email)

    subscriber = NewsletterSubscriber(email=data.email)
    await subscriber.insert()

    return NewsletterResponse(message="Successfully subscribed", email=data.email)


@router.post("/unsubscribe", response_model=NewsletterResponse)
async def unsubscribe_from_newsletter(data: NewsletterSubscribe):
    """Unsubscribe from newsletter"""
    subscriber = await NewsletterSubscriber.find_one(NewsletterSubscriber.email == data.email)

    if not subscriber:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Email not found in subscriber list",
        )

    subscriber.is_active = False
    subscriber.unsubscribed_at = datetime.utcnow()
    await subscriber.save()

    return NewsletterResponse(message="Successfully unsubscribed", email=data.email)
