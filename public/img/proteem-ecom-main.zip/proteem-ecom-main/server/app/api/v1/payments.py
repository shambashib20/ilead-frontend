"""
Payment API Routes

Handles PayPal payment processing including:
- Creating PayPal orders
- Capturing approved payments
- Processing refunds
"""

from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from app.models.order import Order, OrderStatus, PaymentStatus
from app.models.cart import CartItem
from app.models.user import User
from app.api.deps import get_current_user, get_current_admin
from app.utils.paypal import paypal_client, PayPalError
from app.utils.helpers import generate_order_number, calculate_cart_total
from app.models.order import OrderItem, ShippingAddress


router = APIRouter(prefix="/payments", tags=["Payments"])


# ==================== Schemas ====================

class ShippingAddressInput(BaseModel):
    name: str
    street: str
    city: str
    state: str
    zip_code: str
    country: str = "USA"
    phone: Optional[str] = None


class CreatePayPalOrderRequest(BaseModel):
    """Request to create a PayPal order"""
    shipping_address: ShippingAddressInput
    billing_same_as_shipping: bool = True
    billing_address: Optional[ShippingAddressInput] = None
    notes: Optional[str] = None


class CreatePayPalOrderResponse(BaseModel):
    """Response with PayPal order details"""
    paypal_order_id: str
    order_id: str
    approval_url: str
    status: str


class CapturePaymentRequest(BaseModel):
    """Request to capture an approved PayPal payment"""
    paypal_order_id: str


class CapturePaymentResponse(BaseModel):
    """Response after capturing payment"""
    order_id: str
    order_number: str
    payment_status: str
    transaction_id: Optional[str] = None


class RefundRequest(BaseModel):
    """Request to refund a payment"""
    amount: Optional[float] = None  # None for full refund
    reason: Optional[str] = None


class PayPalConfigResponse(BaseModel):
    """PayPal client configuration for frontend"""
    client_id: str
    currency: str = "USD"


# ==================== Routes ====================

@router.get("/config", response_model=PayPalConfigResponse)
async def get_paypal_config():
    """Get PayPal client configuration for frontend SDK"""
    from app.config import settings
    return PayPalConfigResponse(
        client_id=settings.paypal_client_id,
        currency="USD",
    )


@router.post("/paypal/order", response_model=CreatePayPalOrderResponse)
async def create_paypal_order(
    request: CreatePayPalOrderRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Create a PayPal order for checkout
    
    This creates both a local order (pending payment) and a PayPal order.
    The frontend should redirect to the approval_url or use the PayPal JS SDK.
    """
    # Get cart items
    cart_items = await CartItem.find(CartItem.user_id == str(current_user.id)).to_list()
    
    if not cart_items:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cart is empty",
        )
    
    # Calculate totals
    totals = calculate_cart_total(cart_items)
    
    # Create order items
    order_items = [
        OrderItem(
            product_id=item.product_id,
            variant_id=item.variant_id,
            product_name=item.product_name,
            product_image=item.product_image,
            variant_name=item.variant_name,
            unit_price=item.unit_price,
            quantity=item.quantity,
            total_price=item.unit_price * item.quantity,
        )
        for item in cart_items
    ]
    
    # Create shipping address
    shipping = ShippingAddress(**request.shipping_address.model_dump())
    
    # Create local order (pending payment)
    order = Order(
        order_number=generate_order_number(),
        user_id=str(current_user.id),
        items=order_items,
        subtotal=totals["subtotal"],
        tax=totals["tax"],
        shipping_cost=totals["shipping"],
        total=totals["total"],
        shipping_address=shipping,
        billing_same_as_shipping=request.billing_same_as_shipping,
        billing_address=ShippingAddress(**request.billing_address.model_dump()) if request.billing_address else None,
        notes=request.notes,
        status=OrderStatus.PENDING.value,
        payment_status=PaymentStatus.PENDING.value,
    )
    await order.insert()
    
    try:
        # Prepare PayPal items for line-item display
        paypal_items = [
            {
                "name": item.product_name[:127],  # PayPal max 127 chars
                "quantity": str(item.quantity),
                "unit_amount": {
                    "currency_code": "USD",
                    "value": f"{item.unit_price:.2f}",
                },
            }
            for item in cart_items
        ]
        
        # Prepare shipping address for PayPal
        paypal_shipping = {
            "address_line_1": request.shipping_address.street,
            "admin_area_2": request.shipping_address.city,  # City
            "admin_area_1": request.shipping_address.state,  # State
            "postal_code": request.shipping_address.zip_code,
            "country_code": "US" if request.shipping_address.country == "USA" else request.shipping_address.country,
        }
        
        # Create PayPal order
        paypal_response = await paypal_client.create_order(
            amount=totals["total"],
            currency="USD",
            items=paypal_items,
            shipping_address=paypal_shipping,
            reference_id=str(order.id),
            description=f"Proteem Order #{order.order_number}",
            tax_total=totals["tax"],
            shipping_total=totals["shipping"],
        )
        
        # Get approval URL
        approval_url = ""
        for link in paypal_response.get("links", []):
            if link.get("rel") == "approve":
                approval_url = link.get("href", "")
                break
        
        # Update order with PayPal order ID
        order.paypal_order_id = paypal_response["id"]
        await order.save()
        
        return CreatePayPalOrderResponse(
            paypal_order_id=paypal_response["id"],
            order_id=str(order.id),
            approval_url=approval_url,
            status=paypal_response["status"],
        )
        
    except PayPalError as e:
        # Delete the local order if PayPal fails
        await order.delete()
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"PayPal error: {str(e)}",
        )


@router.post("/paypal/capture", response_model=CapturePaymentResponse)
async def capture_paypal_payment(
    request: CapturePaymentRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Capture an approved PayPal payment
    
    Called after the customer approves the payment on PayPal.
    This finalizes the payment and updates the order status.
    """
    # Find the order by PayPal order ID
    order = await Order.find_one(Order.paypal_order_id == request.paypal_order_id)
    
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    
    # Verify ownership
    if order.user_id != str(current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    # Check if already captured
    if order.payment_status == PaymentStatus.PAID.value:
        return CapturePaymentResponse(
            order_id=str(order.id),
            order_number=order.order_number,
            payment_status=order.payment_status,
            transaction_id=order.paypal_capture_id,
        )
    
    try:
        # Capture the payment
        capture_response = await paypal_client.capture_order(request.paypal_order_id)
        
        # Get capture ID from response
        capture_id = None
        captures = (
            capture_response.get("purchase_units", [{}])[0]
            .get("payments", {})
            .get("captures", [])
        )
        if captures:
            capture_id = captures[0].get("id")
        
        # Update order
        order.payment_status = PaymentStatus.PAID.value
        order.status = OrderStatus.CONFIRMED.value
        order.paypal_capture_id = capture_id
        order.updated_at = datetime.utcnow()
        await order.save()
        
        # Clear the cart
        await CartItem.find(CartItem.user_id == str(current_user.id)).delete()
        
        return CapturePaymentResponse(
            order_id=str(order.id),
            order_number=order.order_number,
            payment_status=order.payment_status,
            transaction_id=capture_id,
        )
        
    except PayPalError as e:
        order.payment_status = PaymentStatus.FAILED.value
        order.updated_at = datetime.utcnow()
        await order.save()
        
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Payment capture failed: {str(e)}",
        )


@router.get("/paypal/order/{paypal_order_id}")
async def get_paypal_order_status(
    paypal_order_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get PayPal order status"""
    # Verify the order belongs to the user
    order = await Order.find_one(Order.paypal_order_id == paypal_order_id)
    
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    
    if order.user_id != str(current_user.id) and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    try:
        paypal_order = await paypal_client.get_order(paypal_order_id)
        return {
            "paypal_status": paypal_order.get("status"),
            "order_id": str(order.id),
            "order_status": order.status,
            "payment_status": order.payment_status,
        }
    except PayPalError as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"PayPal error: {str(e)}",
        )


@router.post("/paypal/refund/{order_id}")
async def refund_payment(
    order_id: str,
    request: RefundRequest,
    admin: User = Depends(get_current_admin)
):
    """
    Refund a captured payment (admin only)
    
    Provide amount for partial refund, or leave empty for full refund.
    """
    order = await Order.get(order_id)
    
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    
    if order.payment_status != PaymentStatus.PAID.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Order has not been paid",
        )
    
    if not order.paypal_capture_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No PayPal capture ID found",
        )
    
    try:
        refund_response = await paypal_client.refund_capture(
            capture_id=order.paypal_capture_id,
            amount=request.amount,
            currency="USD",
            note=request.reason,
        )
        
        # Update order status
        order.payment_status = PaymentStatus.REFUNDED.value
        order.status = OrderStatus.REFUNDED.value
        order.updated_at = datetime.utcnow()
        await order.save()
        
        return {
            "success": True,
            "refund_id": refund_response.get("id"),
            "status": refund_response.get("status"),
            "order_id": str(order.id),
        }
        
    except PayPalError as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Refund failed: {str(e)}",
        )
