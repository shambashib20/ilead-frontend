from datetime import datetime
from fastapi import APIRouter, Depends
from app.models.user import User
from app.schemas.user import UserResponse, UserUpdate
from app.api.deps import get_current_user

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserResponse)
async def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """Get current user profile"""
    return UserResponse(**current_user.to_response())


@router.put("/me", response_model=UserResponse)
async def update_current_user(
    user_data: UserUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update current user profile"""
    update_data = user_data.model_dump(exclude_unset=True)

    if update_data:
        for field, value in update_data.items():
            setattr(current_user, field, value)
        current_user.updated_at = datetime.utcnow()
        await current_user.save()

    return UserResponse(**current_user.to_response())
