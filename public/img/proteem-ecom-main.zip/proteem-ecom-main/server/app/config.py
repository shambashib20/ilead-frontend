from pydantic_settings import BaseSettings
from typing import List
from functools import lru_cache


class Settings(BaseSettings):
    # Application
    app_name: str = "Proteem E-commerce API"
    app_version: str = "1.0.0"
    debug: bool = True
    environment: str = "development"
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    
    # MongoDB
    mongodb_url: str = "mongodb://localhost:27017"
    mongodb_db_name: str = "proteem_db"
    
    # JWT
    secret_key: str = "your-super-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    build_commit: str | None = None
    build_ref: str | None = None
    build_time: str | None = None
    
    # Cookies
    cookie_samesite: str = "lax"  # "strict", "lax", or "none"
    cookie_httponly: bool = True
    cookie_domain: str = ""
    
    @property
    def cookie_secure(self) -> bool:
        """Cookie secure flag - automatically True when production is True"""
        return self.environment.lower() in {"prod", "production"} or self.cookie_samesite == "none"

    # CORS
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"
    
    # Frontend
    frontend_url: str = "http://localhost:3000"
    
    # Admin
    admin_email: str = "admin@proteem.com"
    admin_password: str = "changeme123"
    
    # PayPal
    paypal_client_id: str = ""
    paypal_client_secret: str = ""
    paypal_sandbox: bool = True  # Set to False for production
    
    @property
    def paypal_base_url(self) -> str:
        if self.paypal_sandbox:
            return "https://api-m.sandbox.paypal.com"
        return "https://api-m.paypal.com"
    
    @property
    def cors_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.cors_origins.split(",")]
    
    @property
    def env_label(self) -> str:
        """Return a human-friendly environment label."""
        return self.environment or ("production" if not self.debug else "development")
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
    }


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
