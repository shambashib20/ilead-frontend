from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from app.config import settings


class Database:
    client: AsyncIOMotorClient = None


db = Database()


async def connect_to_mongo():
    """Connect to MongoDB"""
    db.client = AsyncIOMotorClient(settings.mongodb_url)
    
    # Import models here to avoid circular imports
    from app.models.user import User
    from app.models.product import Product, Category, ProductVariant
    from app.models.cart import CartItem, WishlistItem
    from app.models.order import Order
    from app.models.newsletter import NewsletterSubscriber
    
    await init_beanie(
        database=db.client[settings.mongodb_db_name],
        document_models=[
            User,
            Category,
            Product,
            ProductVariant,
            CartItem,
            WishlistItem,
            Order,
            NewsletterSubscriber,
        ],
    )
    print(f"Connected to MongoDB: {settings.mongodb_db_name}")


async def close_mongo_connection():
    """Close MongoDB connection"""
    if db.client:
        db.client.close()
        print("MongoDB connection closed")


def get_database():
    """Get database instance"""
    return db.client[settings.mongodb_db_name]
