from typing import Optional, List
from pydantic import BaseModel, Field
from datetime import datetime


# ==================== Category Schemas ====================
class CategoryCreate(BaseModel):
    name: str
    slug: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: bool = True
    sort_order: int = 0


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: Optional[bool] = None
    sort_order: Optional[int] = None


class CategoryResponse(BaseModel):
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: bool
    sort_order: int


# ==================== Product Variant Schemas ====================
class ProductVariantCreate(BaseModel):
    name: str
    sku: Optional[str] = None
    price: Optional[float] = None
    compare_at_price: Optional[float] = None
    stock_quantity: int = 0
    image_url: Optional[str] = None
    is_active: bool = True
    sort_order: int = 0


class ProductVariantResponse(BaseModel):
    id: str
    name: str
    sku: Optional[str] = None
    price: Optional[float] = None
    compare_at_price: Optional[float] = None
    stock_quantity: int
    image_url: Optional[str] = None
    is_active: bool
    sort_order: int


# ==================== Product Schemas ====================
class ProductCreate(BaseModel):
    name: str
    slug: Optional[str] = None
    description: Optional[str] = None
    short_description: Optional[str] = None
    price: float = Field(..., gt=0)
    compare_at_price: Optional[float] = None
    cost_price: Optional[float] = None
    sku: Optional[str] = None
    stock_quantity: int = 0
    track_inventory: bool = True
    allow_backorder: bool = False
    weight: Optional[str] = None
    weight_value: Optional[float] = None
    weight_unit: str = "lbs"
    overview: Optional[str] = None
    benefits: Optional[List[str]] = None
    how_to_use: Optional[str] = None
    ingredients: Optional[List[str]] = None
    training_type: Optional[str] = None
    specifications: Optional[dict] = None
    disclaimer: Optional[str] = None
    image_url: Optional[str] = None
    images: Optional[List[str]] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    is_active: bool = True
    is_featured: bool = False
    category_id: Optional[str] = None
    variants: Optional[List[ProductVariantCreate]] = None


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    short_description: Optional[str] = None
    price: Optional[float] = Field(None, gt=0)
    compare_at_price: Optional[float] = None
    cost_price: Optional[float] = None
    sku: Optional[str] = None
    stock_quantity: Optional[int] = None
    track_inventory: Optional[bool] = None
    allow_backorder: Optional[bool] = None
    weight: Optional[str] = None
    weight_value: Optional[float] = None
    weight_unit: Optional[str] = None
    overview: Optional[str] = None
    benefits: Optional[List[str]] = None
    how_to_use: Optional[str] = None
    ingredients: Optional[List[str]] = None
    training_type: Optional[str] = None
    specifications: Optional[dict] = None
    disclaimer: Optional[str] = None
    image_url: Optional[str] = None
    images: Optional[List[str]] = None
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    is_active: Optional[bool] = None
    is_featured: Optional[bool] = None
    category_id: Optional[str] = None


class ProductCardResponse(BaseModel):
    """Minimal product data for listing cards"""
    id: str
    name: str
    slug: str
    price: float
    compare_at_price: Optional[float] = None
    image_url: Optional[str] = None
    weight: Optional[str] = None
    is_featured: bool
    stock_quantity: int
    category_slug: Optional[str] = None


class ProductDetailResponse(BaseModel):
    """Full product details"""
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    short_description: Optional[str] = None
    price: float
    compare_at_price: Optional[float] = None
    sku: Optional[str] = None
    stock_quantity: int
    weight: Optional[str] = None
    overview: Optional[str] = None
    benefits: Optional[List[str]] = None
    how_to_use: Optional[str] = None
    ingredients: Optional[List[str]] = None
    training_type: Optional[str] = None
    specifications: Optional[dict] = None
    disclaimer: Optional[str] = None
    image_url: Optional[str] = None
    images: Optional[List[str]] = None
    is_featured: bool
    category_id: Optional[str] = None
    category_slug: Optional[str] = None
    variants: Optional[List[ProductVariantResponse]] = None
    created_at: Optional[datetime] = None


class ProductListResponse(BaseModel):
    """Paginated product list"""
    products: List[ProductCardResponse]
    total: int
    page: int
    page_size: int
    total_pages: int
