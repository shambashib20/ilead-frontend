from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime


# ==================== Cart Schemas ====================
class CartItemAdd(BaseModel):
    product_id: str
    variant_id: Optional[str] = None
    quantity: int = 1


class CartItemUpdate(BaseModel):
    quantity: int


class CartItemResponse(BaseModel):
    id: str
    product_id: str
    product_name: str
    product_image: Optional[str] = None
    product_slug: str
    product_weight: Optional[str] = None
    variant_id: Optional[str] = None
    variant_name: Optional[str] = None
    quantity: int
    unit_price: float
    total_price: float


class CartResponse(BaseModel):
    items: List[CartItemResponse]
    subtotal: float
    tax: float
    shipping: float
    total: float
    items_count: int
    total_quantity: int


# ==================== Wishlist Schemas ====================
class WishlistItemAdd(BaseModel):
    product_id: str


class WishlistItemResponse(BaseModel):
    id: str
    product_id: str
    product_name: str
    product_image: Optional[str] = None
    product_slug: str
    product_price: float
    created_at: Optional[datetime] = None


class WishlistResponse(BaseModel):
    items: List[WishlistItemResponse]
    total: int
