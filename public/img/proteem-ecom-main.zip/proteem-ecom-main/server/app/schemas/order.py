from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime


# ==================== Address Schemas ====================
class ShippingAddressInput(BaseModel):
    name: str
    street: str
    city: str
    state: str
    zip_code: str
    country: str = "USA"
    phone: Optional[str] = None


# ==================== Order Item Schemas ====================
class OrderItemResponse(BaseModel):
    product_id: str
    product_name: str
    product_image: Optional[str] = None
    variant_name: Optional[str] = None
    unit_price: float
    quantity: int
    total_price: float


# ==================== Order Schemas ====================
class OrderCreate(BaseModel):
    shipping_address: ShippingAddressInput
    billing_same_as_shipping: bool = True
    billing_address: Optional[ShippingAddressInput] = None
    payment_method: Optional[str] = None
    notes: Optional[str] = None


class OrderResponse(BaseModel):
    id: str
    order_number: str
    status: str
    payment_status: str
    items: List[OrderItemResponse]
    subtotal: float
    tax: float
    shipping_cost: float
    discount: float
    total: float
    shipping_address: ShippingAddressInput
    tracking_number: Optional[str] = None
    created_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None


class OrderListResponse(BaseModel):
    id: str
    order_number: str
    status: str
    payment_status: str
    total: float
    items_count: int
    created_at: Optional[datetime] = None


class OrdersListResponse(BaseModel):
    orders: List[OrderListResponse]
    total: int
    page: int
    page_size: int
