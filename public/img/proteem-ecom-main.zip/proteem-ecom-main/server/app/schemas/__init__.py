# Schemas package
from app.schemas.user import (
    UserCreate,
    UserLogin,
    UserUpdate,
    UserResponse,
    TokenResponse,
    RefreshTokenRequest,
    AddressCreate,
    AddressResponse,
)
from app.schemas.product import (
    CategoryCreate,
    CategoryUpdate,
    CategoryResponse,
    ProductVariantCreate,
    ProductVariantResponse,
    ProductCreate,
    ProductUpdate,
    ProductCardResponse,
    ProductDetailResponse,
    ProductListResponse,
)
from app.schemas.cart import (
    CartItemAdd,
    CartItemUpdate,
    CartItemResponse,
    CartResponse,
    WishlistItemAdd,
    WishlistItemResponse,
    WishlistResponse,
)
from app.schemas.order import (
    ShippingAddressInput,
    OrderItemResponse,
    OrderResponse,
    OrderListResponse,
    OrdersListResponse,
)
from app.schemas.common import (
    NewsletterSubscribe,
    NewsletterResponse,
)

__all__ = [
    # User
    "UserCreate",
    "UserLogin",
    "UserUpdate",
    "UserResponse",
    "TokenResponse",
    "RefreshTokenRequest",
    "AddressCreate",
    "AddressResponse",
    # Product
    "CategoryCreate",
    "CategoryUpdate",
    "CategoryResponse",
    "ProductVariantCreate",
    "ProductVariantResponse",
    "ProductCreate",
    "ProductUpdate",
    "ProductCardResponse",
    "ProductDetailResponse",
    "ProductListResponse",
    # Cart
    "CartItemAdd",
    "CartItemUpdate",
    "CartItemResponse",
    "CartResponse",
    "WishlistItemAdd",
    "WishlistItemResponse",
    "WishlistResponse",
    # Order
    "ShippingAddressInput",
    "OrderItemResponse",
    "OrderResponse",
    "OrderListResponse",
    "OrdersListResponse",
    # Common
    "NewsletterSubscribe",
    "NewsletterResponse",
]
