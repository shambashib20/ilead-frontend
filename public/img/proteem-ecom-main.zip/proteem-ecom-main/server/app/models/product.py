from datetime import datetime
from typing import Optional, List
from beanie import Document, Indexed, Link
from pydantic import Field


class Category(Document):
    """Product category"""
    name: str
    slug: Indexed(str, unique=True)
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: bool = True
    sort_order: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    
    class Settings:
        name = "categories"


class ProductVariant(Document):
    """Product variants for different flavors, sizes, etc."""
    product_id: str  # Reference to parent product
    name: str  # e.g., "Chocolate Peanut Butter"
    sku: Optional[str] = None
    price: Optional[float] = None  # Override product price if set
    compare_at_price: Optional[float] = None
    stock_quantity: int = 0
    image_url: Optional[str] = None
    is_active: bool = True
    sort_order: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "product_variants"


class ProductSpecifications(Document):
    """Flexible product specifications"""
    flavor: Optional[str] = None
    serving_size: Optional[str] = None
    servings_per_container: Optional[str] = None
    allergens: Optional[str] = None
    certifications: Optional[str] = None
    made_in: Optional[str] = None
    storage: Optional[str] = None


class Product(Document):
    """Product model"""
    name: str
    slug: Indexed(str, unique=True)
    description: Optional[str] = None
    short_description: Optional[str] = None
    
    # Pricing
    price: float
    compare_at_price: Optional[float] = None  # Original price for discounts
    cost_price: Optional[float] = None  # For admin/profit calculations
    
    # Inventory
    sku: Optional[str] = None
    stock_quantity: int = 0
    track_inventory: bool = True
    allow_backorder: bool = False
    
    # Physical attributes
    weight: Optional[str] = None  # Display weight e.g., "2.2 lbs"
    weight_value: Optional[float] = None  # Numeric for calculations
    weight_unit: str = "lbs"  # kg, lbs, oz, g
    
    # Product details (matching frontend structure)
    overview: Optional[str] = None  # "24g Protein, 11g Carbs, 3.5g Fat per scoop"
    benefits: Optional[List[str]] = None  # ["Meal replacement", "Post-workout recovery"]
    how_to_use: Optional[str] = None
    ingredients: Optional[List[str]] = None  # ["Whey Protein Isolate", "Cocoa", ...]
    training_type: Optional[str] = None  # "Best for athletes and bodybuilders"
    
    # Specifications as embedded document
    specifications: Optional[dict] = None
    
    # FDA disclaimer
    disclaimer: Optional[str] = None
    
    # Images
    image_url: Optional[str] = None  # Main image
    images: Optional[List[str]] = None  # Additional images
    
    # SEO
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    
    # Status
    is_active: bool = True
    is_featured: bool = False
    
    # Category reference
    category_id: Optional[str] = None
    category_slug: Optional[str] = None
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    
    class Settings:
        name = "products"
    
    def to_card_response(self) -> dict:
        """Convert to product card response (for listing)"""
        return {
            "id": str(self.id),
            "name": self.name,
            "slug": self.slug,
            "price": self.price,
            "compare_at_price": self.compare_at_price,
            "image_url": self.image_url,
            "weight": self.weight,
            "is_featured": self.is_featured,
            "stock_quantity": self.stock_quantity,
            "category_slug": self.category_slug,
        }
    
    def to_detail_response(self) -> dict:
        """Convert to full product detail response"""
        return {
            "id": str(self.id),
            "name": self.name,
            "slug": self.slug,
            "description": self.description,
            "short_description": self.short_description,
            "price": self.price,
            "compare_at_price": self.compare_at_price,
            "sku": self.sku,
            "stock_quantity": self.stock_quantity,
            "weight": self.weight,
            "overview": self.overview,
            "benefits": self.benefits,
            "how_to_use": self.how_to_use,
            "ingredients": self.ingredients,
            "training_type": self.training_type,
            "specifications": self.specifications,
            "disclaimer": self.disclaimer,
            "image_url": self.image_url,
            "images": self.images,
            "is_featured": self.is_featured,
            "category_id": self.category_id,
            "category_slug": self.category_slug,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
