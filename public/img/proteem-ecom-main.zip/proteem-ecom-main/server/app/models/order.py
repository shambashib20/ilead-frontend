from datetime import datetime
from typing import Optional, List
from beanie import Document, Indexed
from pydantic import BaseModel, Field
from enum import Enum


class OrderStatus(str, Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"


class OrderItem(BaseModel):
    """Embedded order item - uses BaseModel since it's embedded in Order document"""
    product_id: str
    variant_id: Optional[str] = None
    product_name: str
    product_sku: Optional[str] = None
    product_image: Optional[str] = None
    variant_name: Optional[str] = None
    unit_price: float
    quantity: int
    total_price: float


class ShippingAddress(BaseModel):
    """Embedded shipping address - uses BaseModel since it's embedded in Order document"""
    name: str
    street: str
    city: str
    state: str
    zip_code: str
    country: str = "USA"
    phone: Optional[str] = None


class Order(Document):
    """Order model"""
    order_number: Indexed(str, unique=True)
    user_id: Indexed(str)
    
    # Status
    status: str = OrderStatus.PENDING.value
    payment_status: str = PaymentStatus.PENDING.value
    
    # Items
    items: List[OrderItem] = []
    
    # Pricing
    subtotal: float
    tax: float = 0
    shipping_cost: float = 0
    discount: float = 0
    total: float
    
    # Shipping
    shipping_address: ShippingAddress
    
    # Billing (optional, same as shipping if not specified)
    billing_same_as_shipping: bool = True
    billing_address: Optional[ShippingAddress] = None
    
    # PayPal Payment
    paypal_order_id: Optional[str] = None  # PayPal order ID
    paypal_capture_id: Optional[str] = None  # PayPal capture/transaction ID
    paypal_payer_id: Optional[str] = None  # PayPal payer ID
    
    # Additional
    notes: Optional[str] = None
    tracking_number: Optional[str] = None
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    
    class Settings:
        name = "orders"
    
    def to_response(self) -> dict:
        return {
            "id": str(self.id),
            "order_number": self.order_number,
            "status": self.status,
            "payment_status": self.payment_status,
            "items": [
                {
                    "product_id": item.product_id,
                    "product_name": item.product_name,
                    "product_image": item.product_image,
                    "variant_name": item.variant_name,
                    "unit_price": item.unit_price,
                    "quantity": item.quantity,
                    "total_price": item.total_price,
                }
                for item in self.items
            ],
            "subtotal": self.subtotal,
            "tax": self.tax,
            "shipping_cost": self.shipping_cost,
            "discount": self.discount,
            "total": self.total,
            "shipping_address": {
                "name": self.shipping_address.name,
                "street": self.shipping_address.street,
                "city": self.shipping_address.city,
                "state": self.shipping_address.state,
                "zip_code": self.shipping_address.zip_code,
                "country": self.shipping_address.country,
                "phone": self.shipping_address.phone,
            },
            "tracking_number": self.tracking_number,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "shipped_at": self.shipped_at.isoformat() if self.shipped_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
        }
    
    def to_list_response(self) -> dict:
        """Condensed response for order listing"""
        return {
            "id": str(self.id),
            "order_number": self.order_number,
            "status": self.status,
            "payment_status": self.payment_status,
            "total": self.total,
            "items_count": len(self.items),
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
