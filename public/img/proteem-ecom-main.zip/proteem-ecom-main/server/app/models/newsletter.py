from datetime import datetime
from typing import Optional
from beanie import Document, Indexed
from pydantic import EmailStr, Field


class NewsletterSubscriber(Document):
    """Newsletter subscription"""
    email: Indexed(EmailStr, unique=True)
    is_active: bool = True
    subscribed_at: datetime = Field(default_factory=datetime.utcnow)
    unsubscribed_at: Optional[datetime] = None
    
    class Settings:
        name = "newsletter_subscribers"
