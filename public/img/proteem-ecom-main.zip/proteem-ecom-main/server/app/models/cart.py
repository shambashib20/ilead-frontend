from datetime import datetime
from typing import Optional
from beanie import Document, Indexed
from pydantic import Field


class CartItem(Document):
    """Shopping cart item"""
    user_id: Indexed(str)
    product_id: str
    variant_id: Optional[str] = None
    quantity: int = 1
    unit_price: float  # Price at time of adding to cart
    
    # Denormalized product info for faster reads
    product_name: str
    product_image: Optional[str] = None
    product_slug: str
    product_weight: Optional[str] = None
    variant_name: Optional[str] = None
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    
    class Settings:
        name = "cart_items"
    
    @property
    def total_price(self) -> float:
        return self.unit_price * self.quantity
    
    def to_response(self) -> dict:
        return {
            "id": str(self.id),
            "product_id": self.product_id,
            "product_name": self.product_name,
            "product_image": self.product_image,
            "product_slug": self.product_slug,
            "product_weight": self.product_weight,
            "variant_id": self.variant_id,
            "variant_name": self.variant_name,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "total_price": self.total_price,
        }


class WishlistItem(Document):
    """User wishlist item"""
    user_id: Indexed(str)
    product_id: str
    
    # Denormalized product info
    product_name: str
    product_image: Optional[str] = None
    product_slug: str
    product_price: float
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "wishlist_items"
    
    def to_response(self) -> dict:
        return {
            "id": str(self.id),
            "product_id": self.product_id,
            "product_name": self.product_name,
            "product_image": self.product_image,
            "product_slug": self.product_slug,
            "product_price": self.product_price,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
