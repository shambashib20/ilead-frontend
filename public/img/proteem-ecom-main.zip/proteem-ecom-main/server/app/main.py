from datetime import datetime

from fastapi import FastAPI
from fastapi.responses import ORJSONResponse

from app.api.router import api_router
from app.core import settings
from app.core.lifecycle import lifespan
from app.core.logging import setup_logging
from app.core.middleware import configure_middlewares

START_TIME = datetime.utcnow()


def create_app() -> FastAPI:
    """Create and configure the FastAPI application instance."""
    setup_logging()

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Proteem E-commerce API",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        default_response_class=ORJSONResponse,
    )

    configure_middlewares(app)
    app.include_router(api_router)
    register_root_routes(app)

    return app


def register_root_routes(app: FastAPI) -> None:
    """Register service metadata and health endpoints."""

    @app.get("/", tags=["Service"])
    async def root():
        """Service info."""
        return {
            "name": settings.app_name,
            "version": settings.app_version,
            "docs": "/docs",
        }

    @app.get("/health", tags=["Service"])
    async def health_check():
        """Health probe for load balancers."""
        return {"status": "healthy"}


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
    )
