import math
from typing import Optional

from app.models.product import Product
from app.schemas.product import ProductCardResponse, ProductListResponse


async def search_products(
    query: str,
    category: Optional[str],
    min_price: Optional[float],
    max_price: Optional[float],
    sort_by: str,
    page: int,
    page_size: int,
) -> ProductListResponse:
    """Search products with filters and pagination."""
    search_query = {
        "is_active": True,
        "$or": [
            {"name": {"$regex": query, "$options": "i"}},
            {"description": {"$regex": query, "$options": "i"}},
            {"short_description": {"$regex": query, "$options": "i"}},
        ],
    }

    if category:
        search_query["category_slug"] = category
    if min_price is not None:
        search_query["price"] = {"$gte": min_price}
    if max_price is not None:
        if "price" in search_query:
            search_query["price"]["$lte"] = max_price
        else:
            search_query["price"] = {"$lte": max_price}

    sort_mapping = {
        "relevance": [("name", 1)],
        "price_asc": [("price", 1)],
        "price_desc": [("-price", -1)],
        "newest": [("-created_at", -1)],
    }
    sort = sort_mapping.get(sort_by, [("name", 1)])

    total = await Product.find(search_query).count()
    skip = (page - 1) * page_size
    products = (
        await Product.find(search_query)
        .sort(sort)
        .skip(skip)
        .limit(page_size)
        .to_list()
    )

    return ProductListResponse(
        products=[ProductCardResponse(**p.to_card_response()) for p in products],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=math.ceil(total / page_size) if total > 0 else 1,
    )
