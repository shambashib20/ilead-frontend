import math
from datetime import datetime
from typing import List, Optional

from fastapi import HTTPException, status

from app.models.product import Category, Product, ProductVariant
from app.schemas.product import (
    CategoryCreate,
    CategoryResponse,
    CategoryUpdate,
    ProductCardResponse,
    ProductCreate,
    ProductDetailResponse,
    ProductListResponse,
    ProductUpdate,
    ProductVariantResponse,
)
from app.utils.helpers import generate_slug


async def list_products(
    page: int,
    page_size: int,
    category: Optional[str],
    featured: Optional[bool],
    min_price: Optional[float],
    max_price: Optional[float],
    sort_by: str,
    search: Optional[str],
) -> ProductListResponse:
    """Return paginated products with filters and sorting."""
    query = {"is_active": True}
    if category:
        query["category_slug"] = category
    if featured is not None:
        query["is_featured"] = featured
    if min_price is not None:
        query["price"] = {"$gte": min_price}
    if max_price is not None:
        if "price" in query:
            query["price"]["$lte"] = max_price
        else:
            query["price"] = {"$lte": max_price}
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}},
        ]

    sort_mapping = {
        "newest": [("-created_at", -1)],
        "price_asc": [("price", 1)],
        "price_desc": [("-price", -1)],
        "name": [("name", 1)],
    }
    sort = sort_mapping.get(sort_by, [("-created_at", -1)])

    total = await Product.find(query).count()
    skip = (page - 1) * page_size
    products = await Product.find(query).sort(sort).skip(skip).limit(page_size).to_list()

    return ProductListResponse(
        products=[ProductCardResponse(**p.to_card_response()) for p in products],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=math.ceil(total / page_size) if total > 0 else 1,
    )


async def get_featured_products(limit: int) -> List[ProductCardResponse]:
    """Return featured products up to provided limit."""
    products = await Product.find(
        {"is_active": True, "is_featured": True}
    ).limit(limit).to_list()
    return [ProductCardResponse(**p.to_card_response()) for p in products]


async def get_product_by_slug(slug: str) -> ProductDetailResponse:
    """Return product by slug with active variants."""
    product = await Product.find_one(Product.slug == slug, Product.is_active == True)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    variants = await ProductVariant.find(
        ProductVariant.product_id == str(product.id),
        ProductVariant.is_active == True,
    ).sort("sort_order").to_list()

    response = product.to_detail_response()
    response["variants"] = [
        ProductVariantResponse(
            id=str(v.id),
            name=v.name,
            sku=v.sku,
            price=v.price,
            compare_at_price=v.compare_at_price,
            stock_quantity=v.stock_quantity,
            image_url=v.image_url,
            is_active=v.is_active,
            sort_order=v.sort_order,
        )
        for v in variants
    ]
    return ProductDetailResponse(**response)


async def get_related_products(slug: str, limit: int) -> List[ProductCardResponse]:
    """Return related products within same category when possible."""
    product = await Product.find_one(Product.slug == slug)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    query = {"is_active": True, "_id": {"$ne": product.id}}
    if product.category_slug:
        query["category_slug"] = product.category_slug

    related = await Product.find(query).limit(limit).to_list()
    return [ProductCardResponse(**p.to_card_response()) for p in related]


async def create_product(product_data: ProductCreate) -> ProductDetailResponse:
    """Create product and optional variants."""
    slug = product_data.slug or generate_slug(product_data.name)
    existing = await Product.find_one(Product.slug == slug)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Product with this slug already exists",
        )

    category_slug = None
    if product_data.category_id:
        category = await Category.get(product_data.category_id)
        if category:
            category_slug = category.slug

    product_dict = product_data.model_dump(exclude={"variants"})
    product_dict["slug"] = slug
    product_dict["category_slug"] = category_slug

    product = Product(**product_dict)
    await product.insert()

    if product_data.variants:
        for variant_data in product_data.variants:
            variant = ProductVariant(
                product_id=str(product.id),
                **variant_data.model_dump(),
            )
            await variant.insert()

    return await get_product_by_slug(product.slug)


async def update_product(product_id: str, product_data: ProductUpdate) -> ProductDetailResponse:
    """Update product with new data."""
    product = await Product.get(product_id)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    update_data = product_data.model_dump(exclude_unset=True)
    if "category_id" in update_data:
        if update_data["category_id"]:
            category = await Category.get(update_data["category_id"])
            update_data["category_slug"] = category.slug if category else None
        else:
            update_data["category_slug"] = None

    if update_data:
        for field, value in update_data.items():
            setattr(product, field, value)
        product.updated_at = datetime.utcnow()
        await product.save()

    return await get_product_by_slug(product.slug)


async def delete_product(product_id: str) -> None:
    """Delete product and its variants."""
    product = await Product.get(product_id)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    await ProductVariant.find(ProductVariant.product_id == product_id).delete()
    await product.delete()


async def list_categories() -> list[CategoryResponse]:
    """List active categories ordered by sort order."""
    categories = await Category.find(Category.is_active == True).sort("sort_order").to_list()
    return [
        CategoryResponse(
            id=str(c.id),
            name=c.name,
            slug=c.slug,
            description=c.description,
            image_url=c.image_url,
            is_active=c.is_active,
            sort_order=c.sort_order,
        )
        for c in categories
    ]


async def get_category(slug: str) -> CategoryResponse:
    """Get category by slug."""
    category = await Category.find_one(Category.slug == slug)
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )
    return CategoryResponse(
        id=str(category.id),
        name=category.name,
        slug=category.slug,
        description=category.description,
        image_url=category.image_url,
        is_active=category.is_active,
        sort_order=category.sort_order,
    )


async def create_category(category_data: CategoryCreate) -> CategoryResponse:
    """Create category with unique slug."""
    slug = category_data.slug or generate_slug(category_data.name)
    existing = await Category.find_one(Category.slug == slug)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Category with this slug already exists",
        )

    category = Category(
        name=category_data.name,
        slug=slug,
        description=category_data.description,
        image_url=category_data.image_url,
        is_active=category_data.is_active,
        sort_order=category_data.sort_order,
    )
    await category.insert()
    return CategoryResponse(
        id=str(category.id),
        name=category.name,
        slug=category.slug,
        description=category.description,
        image_url=category.image_url,
        is_active=category.is_active,
        sort_order=category.sort_order,
    )


async def update_category(category_id: str, category_data: CategoryUpdate) -> CategoryResponse:
    """Update an existing category."""
    category = await Category.get(category_id)
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )

    update_data = category_data.model_dump(exclude_unset=True)
    if update_data:
        for field, value in update_data.items():
            setattr(category, field, value)
        await category.save()

    return CategoryResponse(
        id=str(category.id),
        name=category.name,
        slug=category.slug,
        description=category.description,
        image_url=category.image_url,
        is_active=category.is_active,
        sort_order=category.sort_order,
    )


async def delete_category(category_id: str) -> None:
    """Delete a category."""
    category = await Category.get(category_id)
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )
    await category.delete()
