from datetime import datetime
from typing import Optional

from fastapi import HTTPException, status

from app.models.cart import CartItem
from app.models.order import Order, OrderItem, OrderStatus, ShippingAddress
from app.models.user import User
from app.schemas.order import (
    OrderCreate,
    OrderListResponse,
    OrderResponse,
    OrdersListResponse,
)
from app.utils.helpers import calculate_cart_total, generate_order_number


async def list_orders_for_user(
    user: User, page: int, page_size: int, status_filter: Optional[str]
) -> OrdersListResponse:
    """Return paginated orders for a user."""
    query = {"user_id": str(user.id)}
    if status_filter:
        query["status"] = status_filter

    total = await Order.find(query).count()
    skip = (page - 1) * page_size
    orders = (
        await Order.find(query)
        .sort("-created_at")
        .skip(skip)
        .limit(page_size)
        .to_list()
    )

    return OrdersListResponse(
        orders=[
            OrderListResponse(
                id=str(o.id),
                order_number=o.order_number,
                status=o.status,
                payment_status=o.payment_status,
                total=o.total,
                items_count=len(o.items),
                created_at=o.created_at,
            )
            for o in orders
        ],
        total=total,
        page=page,
        page_size=page_size,
    )


async def get_order_detail(order_id: str, current_user: User) -> OrderResponse:
    """Return an order ensuring the requester has access."""
    order = await Order.get(order_id)
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    if order.user_id != str(current_user.id) and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    return OrderResponse(**order.to_response())


async def create_order_from_cart(order_data: OrderCreate, current_user: User) -> OrderResponse:
    """Create an order from the current user's cart and clear the cart."""
    cart_items = await CartItem.find(CartItem.user_id == str(current_user.id)).to_list()
    if not cart_items:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cart is empty",
        )

    totals = calculate_cart_total(cart_items)
    order_items = [
        OrderItem(
            product_id=item.product_id,
            variant_id=item.variant_id,
            product_name=item.product_name,
            product_image=item.product_image,
            variant_name=item.variant_name,
            unit_price=item.unit_price,
            quantity=item.quantity,
            total_price=item.unit_price * item.quantity,
        )
        for item in cart_items
    ]

    shipping = ShippingAddress(**order_data.shipping_address.model_dump())

    order = Order(
        order_number=generate_order_number(),
        user_id=str(current_user.id),
        items=order_items,
        subtotal=totals["subtotal"],
        tax=totals["tax"],
        shipping_cost=totals["shipping"],
        total=totals["total"],
        shipping_address=shipping,
        billing_same_as_shipping=order_data.billing_same_as_shipping,
        billing_address=ShippingAddress(**order_data.billing_address.model_dump())
        if order_data.billing_address
        else None,
        payment_method=order_data.payment_method,
        notes=order_data.notes,
    )
    await order.insert()
    await CartItem.find(CartItem.user_id == str(current_user.id)).delete()

    return OrderResponse(**order.to_response())


async def cancel_order(order_id: str, current_user: User) -> OrderResponse:
    """Cancel an order when allowed."""
    order = await Order.get(order_id)
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    if order.user_id != str(current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    if order.status not in [OrderStatus.PENDING.value, OrderStatus.CONFIRMED.value]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Order cannot be cancelled",
        )

    order.status = OrderStatus.CANCELLED.value
    order.updated_at = datetime.utcnow()
    await order.save()
    return OrderResponse(**order.to_response())


async def update_order_status(
    order_id: str, new_status: str, tracking_number: Optional[str]
) -> OrderResponse:
    """Update order status (admin)."""
    order = await Order.get(order_id)
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    valid_statuses = [s.value for s in OrderStatus]
    if new_status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status. Must be one of: {valid_statuses}",
        )

    order.status = new_status
    order.updated_at = datetime.utcnow()

    if tracking_number:
        order.tracking_number = tracking_number

    if new_status == OrderStatus.SHIPPED.value:
        order.shipped_at = datetime.utcnow()
    elif new_status == OrderStatus.DELIVERED.value:
        order.delivered_at = datetime.utcnow()

    await order.save()
    return OrderResponse(**order.to_response())
