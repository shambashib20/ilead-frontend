from datetime import datetime
from typing import Optional

from fastapi import HTTPException, status

from app.models.cart import CartItem, WishlistItem
from app.models.product import Product
from app.schemas.cart import (
    CartItemAdd,
    CartItemResponse,
    CartItemUpdate,
    CartResponse,
    WishlistItemAdd,
    WishlistItemResponse,
    WishlistResponse,
)
from app.utils.helpers import calculate_cart_total


async def get_cart_for_user(user_id: str) -> CartResponse:
    """Return the cart for a user including totals."""
    items = await CartItem.find(CartItem.user_id == user_id).to_list()
    totals = calculate_cart_total(items)
    return CartResponse(
        items=[CartItemResponse(**item.to_response()) for item in items],
        **totals,
    )


async def add_item_to_cart(user_id: str, item_data: CartItemAdd) -> CartItemResponse:
    """Add an item to cart or increase quantity if it exists."""
    product = await Product.get(item_data.product_id)
    if not product or not product.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    existing_item = await CartItem.find_one(
        CartItem.user_id == user_id,
        CartItem.product_id == item_data.product_id,
        CartItem.variant_id == item_data.variant_id,
    )

    if existing_item:
        existing_item.quantity += item_data.quantity
        existing_item.updated_at = datetime.utcnow()
        await existing_item.save()
        return CartItemResponse(**existing_item.to_response())

    cart_item = CartItem(
        user_id=user_id,
        product_id=item_data.product_id,
        variant_id=item_data.variant_id,
        quantity=item_data.quantity,
        unit_price=product.price,
        product_name=product.name,
        product_image=product.image_url,
        product_slug=product.slug,
        product_weight=product.weight,
    )
    await cart_item.insert()
    return CartItemResponse(**cart_item.to_response())


async def update_cart_item(user_id: str, item_id: str, item_data: CartItemUpdate) -> CartItemResponse:
    """Update quantity or remove item when quantity is zero or less."""
    cart_item = await CartItem.get(item_id)
    if not cart_item or cart_item.user_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cart item not found",
        )

    if item_data.quantity <= 0:
        await cart_item.delete()
        raise HTTPException(
            status_code=status.HTTP_200_OK,
            detail="Item removed from cart",
        )

    cart_item.quantity = item_data.quantity
    cart_item.updated_at = datetime.utcnow()
    await cart_item.save()
    return CartItemResponse(**cart_item.to_response())


async def remove_cart_item(user_id: str, item_id: str) -> None:
    """Remove a cart item belonging to a user."""
    cart_item = await CartItem.get(item_id)
    if not cart_item or cart_item.user_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cart item not found",
        )
    await cart_item.delete()


async def clear_cart(user_id: str) -> None:
    """Remove all cart items for a user."""
    await CartItem.find(CartItem.user_id == user_id).delete()


async def get_wishlist(user_id: str) -> WishlistResponse:
    """Return wishlist for a user."""
    items = await WishlistItem.find(WishlistItem.user_id == user_id).to_list()
    return WishlistResponse(
        items=[WishlistItemResponse(**item.to_response()) for item in items],
        total=len(items),
    )


async def add_to_wishlist(user_id: str, item_data: WishlistItemAdd) -> WishlistItemResponse:
    """Add a product to wishlist if not present."""
    product = await Product.get(item_data.product_id)
    if not product or not product.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    existing = await WishlistItem.find_one(
        WishlistItem.user_id == user_id,
        WishlistItem.product_id == item_data.product_id,
    )
    if existing:
        return WishlistItemResponse(**existing.to_response())

    wishlist_item = WishlistItem(
        user_id=user_id,
        product_id=item_data.product_id,
        product_name=product.name,
        product_image=product.image_url,
        product_slug=product.slug,
        product_price=product.price,
    )
    await wishlist_item.insert()
    return WishlistItemResponse(**wishlist_item.to_response())


async def remove_from_wishlist(user_id: str, item_id: str) -> None:
    """Remove a wishlist item."""
    wishlist_item = await WishlistItem.get(item_id)
    if not wishlist_item or wishlist_item.user_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Wishlist item not found",
        )
    await wishlist_item.delete()


async def move_wishlist_item_to_cart(user_id: str, item_id: str) -> CartItemResponse:
    """Move a wishlist item into the cart and delete it from wishlist."""
    wishlist_item = await WishlistItem.get(item_id)
    if not wishlist_item or wishlist_item.user_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Wishlist item not found",
        )

    cart_response = await add_item_to_cart(
        user_id, CartItemAdd(product_id=wishlist_item.product_id, quantity=1)
    )
    await wishlist_item.delete()
    return cart_response
